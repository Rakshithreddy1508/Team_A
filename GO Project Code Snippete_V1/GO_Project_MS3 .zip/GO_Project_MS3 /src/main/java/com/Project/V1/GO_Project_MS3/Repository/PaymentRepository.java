package com.Project.V1.GO_Project_MS3.Repository;

import org.springframework.data.jpa.repository.JpaRepository;


import com.Project.V1.GO_Project_MS3.Entity.PaymentEntity;

public interface PaymentRepository extends JpaRepository<PaymentEntity,String>{

}
