package com.Project.V1.GO_Project_MS3.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Project.V1.GO_Project_MS3.DTO.OrderResponse;
import com.Project.V1.GO_Project_MS3.DTO.PaymentRequest;
import com.Project.V1.GO_Project_MS3.DTO.PaymentResponse;
import com.Project.V1.GO_Project_MS3.Entity.OrderEntity;
import com.Project.V1.GO_Project_MS3.Entity.PaymentEntity;
import com.Project.V1.GO_Project_MS3.Mapper.PaymentMapper;
import com.Project.V1.GO_Project_MS3.Repository.PaymentRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class PaymentServiceimpl implements PaymentService {

	
	@Autowired
    private PaymentRepository paymentRepository; // You need to define a repository
    @Autowired
	private PaymentMapper paymentMapper;
    
 @Override
    public PaymentResponse createPayment(PaymentRequest paymentRequest) {
        PaymentEntity paymentEntity = paymentMapper.toEntity(paymentRequest);
        paymentEntity = paymentRepository.save(paymentEntity);
        return paymentMapper.toResponse(paymentEntity);
    }

 @Override
 public PaymentResponse updatePayment(String id, PaymentRequest paymentRequest)  {
     PaymentEntity existingPayment=paymentRepository.findById(id)
             .orElseThrow(() -> new EntityNotFoundException("Payment not found"));
     
     existingPayment.setAmount(paymentRequest.getAmount());
     existingPayment = paymentRepository.save(existingPayment);
     return paymentMapper.toResponse(existingPayment);
 }
 @Override
 public List<PaymentResponse> getAllPayment() {
         List<PaymentEntity> paymentEntity = paymentRepository.findAll();
         return paymentEntity.stream()
             .map(paymentMapper::toResponse)
             .collect(Collectors.toList());
 }
 
 @Override
 public PaymentResponse getPaymentById(String id) {
     PaymentEntity paymentEntity = paymentRepository.findById(id)
             .orElseThrow(() -> new EntityNotFoundException("User not found"));
     return paymentMapper.toResponse(paymentEntity);
 }
 
 @Override
 public void deletePayment(String id) {
     PaymentEntity paymentEntity = paymentRepository.findById(id)
             .orElseThrow(() -> new EntityNotFoundException("User not found"));
     paymentRepository.delete(paymentEntity);
 }
}

