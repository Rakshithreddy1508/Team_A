package com.Project.V1.GO_Project_MS3.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.Project.V1.GO_Project_MS3.DTO.OrderRequest;
import com.Project.V1.GO_Project_MS3.DTO.OrderResponse;
import com.Project.V1.GO_Project_MS3.Entity.OrderEntity;
import com.Project.V1.GO_Project_MS3.Mapper.OrderMapper;
import com.Project.V1.GO_Project_MS3.Repository.OrderRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class OrderServiceimpl implements OrderService{

	
	@Autowired
    private OrderRepository orderRepository; 
    
	@Autowired
	private OrderMapper orderMapper;
   
    @Override
    
    public OrderResponse createOrder(OrderRequest orderRequest) {
        OrderEntity orderEntity = orderMapper.toEntity(orderRequest);
        orderEntity = orderRepository.save(orderEntity);
        return orderMapper.toResponse(orderEntity);
    }

    @Override
    public OrderResponse updateOrder(String id, OrderRequest orderRequest)  {
        OrderEntity existingOrder=orderRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Order not found"));
        
        existingOrder.setOrder_ref_no(orderRequest.getOrder_ref_no());
        
        existingOrder = orderRepository.save(existingOrder);
        return orderMapper.toResponse(existingOrder);
    }
    @Override
    public List<OrderResponse> getAllOrder() {
            List<OrderEntity> orderEntities = orderRepository.findAll();
            return orderEntities.stream()
                .map(orderMapper::toResponse)
                .collect(Collectors.toList());
    }
    
    @Override
    public OrderResponse getOrderById(String id) {
        OrderEntity orderEntity = orderRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("User not found"));
        return orderMapper.toResponse(orderEntity);
    }
    
    @Override
    public void deleteOrder(String id) {
        OrderEntity order = orderRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("User not found"));
        orderRepository.delete(order);
    }

    
 
}




	
   

