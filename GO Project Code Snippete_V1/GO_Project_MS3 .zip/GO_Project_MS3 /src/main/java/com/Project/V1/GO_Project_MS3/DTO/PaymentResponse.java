package com.Project.V1.GO_Project_MS3.DTO;

public class PaymentResponse {

	 private String id;
	 private double amount ;
	 private double gst;
	 private double pg_charge ;
	
	 public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getGst() {
		return gst;
	}
	public void setGst(double gst) {
		this.gst = gst;
	}
	public double getPg_charge() {
		return pg_charge;
	}
	public void setPg_charge(double pg_charge) {
		this.pg_charge = pg_charge;
	}
	

}
