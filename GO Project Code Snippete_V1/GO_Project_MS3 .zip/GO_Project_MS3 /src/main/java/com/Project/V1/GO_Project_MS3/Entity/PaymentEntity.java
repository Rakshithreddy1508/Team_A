package com.Project.V1.GO_Project_MS3.Entity;

import java.util.Objects;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name = "payment_details")
public class PaymentEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	private String id;
	
	private double amount ;
    private double gst;
    private double pg_charge ;
    private double total_amount ;
    private String payment_ref_no;
    private String payment_method; 
    
    public PaymentEntity(String id, double amount, double gst, double pg_charge, double total_amount, String payment_ref_no,
			String payment_method) {
		super();
		this.id = id;
		this.amount = amount;
		this.gst = gst;
		this.pg_charge = pg_charge;
		this.total_amount = total_amount;
		this.payment_ref_no = payment_ref_no;
		this.payment_method = payment_method;
	}
	public PaymentEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Payment [id=" + id + ", amount=" + amount + ", gst=" + gst + ", pg_charge=" + pg_charge
				+ ", total_amount=" + total_amount + ", payment_ref_no=" + payment_ref_no + ", payment_method="
				+ payment_method + "]";
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public double getGst() {
		return gst;
	}
	public void setGst(double gst) {
		this.gst = gst;
	}
	public double getPg_charge() {
		return pg_charge;
	}
	public void setPg_charge(double pg_charge) {
		this.pg_charge = pg_charge;
	}
	public double getTotal_amount() {
		return total_amount;
	}
	public void setTotal_amount(double total_amount) {
		this.total_amount = total_amount;
	}
	public String getPayment_ref_no() {
		return payment_ref_no;
	}
	public void setPayment_ref_no(String payment_ref_no) {
		this.payment_ref_no = payment_ref_no;
	}
	public String getPayment_method() {
		return payment_method;
	}
	public void setPayment_method(String payment_method) {
		this.payment_method = payment_method;
	}
	
}
