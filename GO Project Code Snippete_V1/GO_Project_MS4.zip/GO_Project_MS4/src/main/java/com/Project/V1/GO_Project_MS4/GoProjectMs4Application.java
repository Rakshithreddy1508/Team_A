package com.Project.V1.GO_Project_MS4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoProjectMs4Application {

	public static void main(String[] args) {
		SpringApplication.run(GoProjectMs4Application.class, args);
	}

}
