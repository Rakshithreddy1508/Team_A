package com.Project.V1.GO_Project_MS4.service;

import java.util.List;

import com.Project.V1.GO_Project_MS4.DTO.CommentRequest;
import com.Project.V1.GO_Project_MS4.DTO.CommentResponse;

public interface CommentService {

    CommentResponse createComment(CommentRequest commentRequest);

    CommentResponse updateComment(String id, CommentRequest commentRequest);
    CommentResponse getCommentById(String id);
    void deleteComment(String id);

	List<CommentResponse> getAllComment()throws Exception;


}
