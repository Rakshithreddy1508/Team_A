package com.Project.V1.GO_Project_MS4.Mapper;

import org.springframework.stereotype.Component;

import com.Project.V1.GO_Project_MS4.DTO.CommentRequest;
import com.Project.V1.GO_Project_MS4.DTO.CommentResponse;
import com.Project.V1.GO_Project_MS4.entity.CommentEntity;


@Component
public class CommentMapper {

	public CommentEntity toEntity(CommentRequest commentRequest) {
        CommentEntity commentEntity = new CommentEntity();
        commentEntity.setProduct_id(commentRequest.getProduct_id());
        commentEntity.setComment(commentRequest.getComment());
        // Map other properties
        return commentEntity;
 }

	public CommentResponse toResponse(CommentEntity commentEntity) {
		CommentResponse commentResponse = new CommentResponse();
        commentResponse.setId(commentEntity.getId());
        commentResponse.setProduct_id(commentEntity.getProduct_id());
        commentResponse.setComment(commentEntity.getComment());
        // Map other properties
        return commentResponse;
    }
}