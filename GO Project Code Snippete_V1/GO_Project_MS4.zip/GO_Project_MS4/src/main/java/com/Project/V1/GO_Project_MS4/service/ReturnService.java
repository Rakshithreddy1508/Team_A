package com.Project.V1.GO_Project_MS4.service;

import java.util.List;

import com.Project.V1.GO_Project_MS4.DTO.ReturnRequest;
import com.Project.V1.GO_Project_MS4.DTO.ReturnResponse;

public interface ReturnService {

	ReturnResponse createreturn(ReturnRequest returnRequest);

	ReturnResponse updatereturn(String id, ReturnRequest ReturnRequest);
	ReturnResponse getreturnById(String id);
    void deletereturn(String id);

	List<ReturnResponse> getAllreturn()throws Exception;

}
