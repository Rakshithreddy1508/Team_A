package com.Project.V1.GO_Project_MS4.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="comment_details")
public class CommentEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	private String id;
	private String comment;
	private String product_id;

	public CommentEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CommentEntity(String id, String comment, String product_id) {
		super();
		this.id = id;
		this.comment = comment;
		this.product_id = product_id;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getProduct_id() {
		return product_id;
	}
	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}

	@Override
	public String toString() {
		return "Commententity [id=" + id + ", comment=" + comment + ", product_id=" + product_id + "]";
	}



}
