package com.Project.V1.GO_Project_MS4;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.Project.V1.GO_Project_MS4.DTO.CommentRequest;
import com.Project.V1.GO_Project_MS4.DTO.CommentResponse;
import com.Project.V1.GO_Project_MS4.Mapper.CommentMapper;
import com.Project.V1.GO_Project_MS4.entity.CommentEntity;
import com.Project.V1.GO_Project_MS4.repository.CommentRepo;
import com.Project.V1.GO_Project_MS4.service.CommentServiceImpl;

@ExtendWith(MockitoExtension.class)
class CommentServiceImplTest {

    @InjectMocks
    private CommentServiceImpl commentService;

    @Mock
    private CommentRepo commentRepo;

    @Mock
    private CommentMapper commentMapper;

    @Test
    void testCreateComment() {
        CommentRequest request = new CommentRequest(/* provide necessary parameters */);
        CommentEntity entity = new CommentEntity(/* provide necessary parameters */);
        CommentResponse response = new CommentResponse(/* provide expected response parameters */);
        when(commentMapper.toEntity(request)).thenReturn(entity);
        when(commentRepo.save(entity)).thenReturn(entity);
        when(commentMapper.toResponse(entity)).thenReturn(response);
        CommentResponse result = commentService.createComment(request);
        verify(commentMapper).toEntity(request);
        verify(commentRepo).save(entity);
        verify(commentMapper).toResponse(entity);


    }

    @Test
    void testUpdateComment() {
        String commentId = "yourId"; // provide an existing ID
        CommentRequest request = new CommentRequest(/* provide necessary parameters */);
        CommentEntity entity = new CommentEntity(/* provide necessary parameters */);
        CommentResponse response = new CommentResponse(/* provide expected response parameters */);
        when(commentRepo.findById(commentId)).thenReturn(Optional.of(entity));
        when(commentRepo.save(entity)).thenReturn(entity);
        when(commentMapper.toResponse(entity)).thenReturn(response);
        CommentResponse result = commentService.updateComment(commentId, request);
        verify(commentRepo).findById(commentId);
        verify(commentRepo).save(entity);
        verify(commentMapper).toResponse(entity);

    }
    @Test
    void testdeleteComment() {
        String commentId = "yourId"; // provide an existing ID
        CommentRequest request = new CommentRequest(/* provide necessary parameters */);
        CommentEntity entity = new CommentEntity(/* provide necessary parameters */);
        CommentResponse response = new CommentResponse(/* provide expected response parameters */);
        when(commentRepo.findById(commentId)).thenReturn(Optional.of(entity));
        when(commentRepo.save(entity)).thenReturn(entity);
        when(commentMapper.toResponse(entity)).thenReturn(response);
        CommentResponse result = commentService.updateComment(commentId, request);
        verify(commentRepo).findById(commentId);
        verify(commentRepo).save(entity);
        verify(commentMapper).toResponse(entity);
    }
    @Test
    void testgetCommentById() {
        String commentId = "yourId"; // provide an existing ID
        CommentRequest request = new CommentRequest(/* provide necessary parameters */);
        CommentEntity entity = new CommentEntity(/* provide necessary parameters */);
        CommentResponse response = new CommentResponse(/* provide expected response parameters */);
        when(commentRepo.findById(commentId)).thenReturn(Optional.of(entity));
        when(commentRepo.save(entity)).thenReturn(entity);
        when(commentMapper.toResponse(entity)).thenReturn(response);
        CommentResponse result = commentService.updateComment(commentId, request);
        verify(commentRepo).findById(commentId);
        verify(commentRepo).save(entity);
        verify(commentMapper).toResponse(entity);
}
}