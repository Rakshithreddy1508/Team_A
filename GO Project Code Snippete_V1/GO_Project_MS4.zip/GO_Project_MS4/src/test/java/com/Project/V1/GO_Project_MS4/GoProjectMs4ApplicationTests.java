package com.Project.V1.GO_Project_MS4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoProjectMs4ApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	void ytestcase() {
		System.out.println("Everything is running fine");
	}

//	@Test
//	public void testReturnEntity() throws URISyntaxException
//	{
//	    RestTemplate restTemplate = new RestTemplate();
//	    //String randomServerPort="8080";
//	    System.out.println("TestCase is Going ON");
//	    final String baseUrl = "http://localhost:6004"+ "/Return/return";
//	    URI uri = new URI(baseUrl);
//	    ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
//	    //Verify request succeed
//	    assertEquals(200, result.getStatusCodeValue());
//	}
}
