package com.Project.V1.GO_Project_MS4;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.Project.V1.GO_Project_MS4.DTO.ReturnRequest;
import com.Project.V1.GO_Project_MS4.DTO.ReturnResponse;
import com.Project.V1.GO_Project_MS4.Mapper.ReturnMapper;
import com.Project.V1.GO_Project_MS4.entity.ReturnEntity;
import com.Project.V1.GO_Project_MS4.repository.ReturnRepo;
import com.Project.V1.GO_Project_MS4.service.ReturnServiceImpl;

@ExtendWith(MockitoExtension.class)
class ReturnServiceImplTest {

    @InjectMocks
    private ReturnServiceImpl returnService;

    @Mock
    private ReturnRepo returnRepo;

    @Mock
    private ReturnMapper returnMapper;

    @Test
    void testCreateReturn() {
        ReturnRequest request = new ReturnRequest(/* provide necessary parameters */);
        ReturnEntity entity = new ReturnEntity(/* provide necessary parameters */);
        ReturnResponse response = new ReturnResponse(/* provide expected response parameters */);

        when(returnMapper.toEntity(request)).thenReturn(entity);
        when(returnRepo.save(entity)).thenReturn(entity);
        when(returnMapper.toResponse(entity)).thenReturn(response);

        ReturnResponse result = returnService.createreturn(request);

        verify(returnMapper).toEntity(request);
        verify(returnRepo).save(entity);
        verify(returnMapper).toResponse(entity);

        // Add assertions based on the expected result and 'result' obtained from the service method
        // For example: assertEquals(expectedResponse, result);
    }

    @Test
    void testUpdateReturn() {
        String returnId = "yourId"; // provide an existing ID
        ReturnRequest request = new ReturnRequest(/* provide necessary parameters */);
        ReturnEntity entity = new ReturnEntity(/* provide necessary parameters */);
        ReturnResponse response = new ReturnResponse(/* provide expected response parameters */);

        when(returnRepo.findById(returnId)).thenReturn(Optional.of(entity));
        when(returnRepo.save(entity)).thenReturn(entity);
        when(returnMapper.toResponse(entity)).thenReturn(response);

        ReturnResponse result = returnService.updatereturn(returnId, request);

        verify(returnRepo).findById(returnId);
        verify(returnRepo).save(entity);
        verify(returnMapper).toResponse(entity);

        // Add assertions based on the expected result and 'result' obtained from the service method
        // For example: assertEquals(expectedResponse, result);
    }

    @Test
    void testGetReturnById() {
        String returnId = "yourId"; // provide an existing ID
        ReturnEntity entity = new ReturnEntity(/* provide necessary parameters */);
        ReturnResponse response = new ReturnResponse(/* provide expected response parameters */);

        when(returnRepo.findById(returnId)).thenReturn(Optional.of(entity));
        when(returnMapper.toResponse(entity)).thenReturn(response);

        ReturnResponse result = returnService.getreturnById(returnId);

        verify(returnRepo).findById(returnId);
        verify(returnMapper).toResponse(entity);

        // Add assertions based on the expected result and 'result' obtained from the service method
        // For example: assertEquals(expectedResponse, result);
    }

    @Test
    void testDeleteReturn() {
        String returnId = "yourId"; // provide an existing ID
        ReturnEntity entity = new ReturnEntity(/* provide necessary parameters */);

        when(returnRepo.findById(returnId)).thenReturn(Optional.of(entity));

        returnService.deletereturn(returnId);

        verify(returnRepo).findById(returnId);
        verify(returnRepo).delete(entity);

        // Add assertions or verify statements for the delete method behavior
        // For example: verify(returnRepo, times(1)).delete(entity);
    }
}
