package com.Project.V1.GO_Project_MS1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoProjectMs1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
