package com.Project.V1.GO_Project_MS1.service;

import java.util.List;

import com.Project.V1.GO_Project_MS1.DTO.UserRequest;
import com.Project.V1.GO_Project_MS1.DTO.UserResponse;

public interface UserService {
    
	UserResponse createUser(UserRequest userRequest) throws Exception ;
	
	UserResponse updateUser(String id, UserRequest userRequest) throws Exception; 
	
	List<UserResponse> getAllUsers() throws Exception;
	
	UserResponse getUserById(String userId);
	
    void deleteUser(String id);
    
    UserResponse signUpUser(UserRequest userRequest) throws Exception;
    UserResponse signInUser(UserRequest userRequest) throws Exception;
    
}
