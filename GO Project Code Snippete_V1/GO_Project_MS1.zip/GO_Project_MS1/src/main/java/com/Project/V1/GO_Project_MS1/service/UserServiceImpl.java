package com.Project.V1.GO_Project_MS1.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.Project.V1.GO_Project_MS1.DTO.UserRequest;
import com.Project.V1.GO_Project_MS1.DTO.UserResponse;
import com.Project.V1.GO_Project_MS1.Entity.UserEntity;
import com.Project.V1.GO_Project_MS1.Mapper.UserMapper;
import com.Project.V1.GO_Project_MS1.Repository.UserRepo;

import jakarta.persistence.EntityNotFoundException;

@Service
public class UserServiceImpl implements UserService{

	
	@Autowired
    private UserRepo userRepository; // You need to define a repository

    @Autowired
    private UserMapper userMapper;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
   

    @Override
    public UserResponse signUpUser(UserRequest userRequest) throws Exception {
        if (userRepository.existsByUserEmailId(userRequest.getEmailId())) {
            throw new Exception("Email is already in use");
        }

        UserEntity userEntity = userMapper.toEntity(userRequest);
        userEntity.setPassword(passwordEncoder.encode(userEntity.getPassword())); // Hash the password
        userEntity = userRepository.save(userEntity);

        return userMapper.toResponse(userEntity);
    }



    @Override
    public UserResponse signInUser(UserRequest userRequest) throws Exception {
        String emailId = userRequest.getEmailId();
        String password = userRequest.getPassword();
        
        UserEntity userEntity = userRepository.findByEmailId(emailId).orElseThrow(() -> new Exception("User with email not found: " + emailId));

        if (!passwordEncoder.matches(password, userEntity.getPassword())) {
            throw new Exception("Invalid credentials");
        }

        return userMapper.toResponse(userEntity);
    }

    
    
    @Override
    public UserResponse createUser(UserRequest userRequest){

            UserEntity userEntity = userMapper.toEntity(userRequest);
            userEntity = userRepository.save(userEntity);
            return userMapper.toResponse(userEntity);
    }

    @Override
    public UserResponse updateUser(String id, UserRequest userRequest){

        	UserEntity existingUser = userRepository.findById(id)
        
                .orElseThrow(() -> new EntityNotFoundException("User not found"));
        
        existingUser.setFirstName(userRequest.getFirstName());
        existingUser.setLastName(userRequest.getLastName());
        
        existingUser = userRepository.save(existingUser);
        return userMapper.toResponse(existingUser);
    }
    
    @Override
    public List<UserResponse> getAllUsers() {
            List<UserEntity> userEntities = userRepository.findAll();
            return userEntities.stream()
                .map(userMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public UserResponse getUserById(String userId){
        	UserEntity userEntity = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException("User not found"));
        return userMapper.toResponse(userEntity);
    }
    
    @Override
    public void deleteUser(String id) {
        UserEntity user = userRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("User not found"));
        userRepository.delete(user);
    }
}


