package com.Project.V1.GO_Project_MS1.Entity;

public enum Role {
	
	USER,
	
	ADMIN

}
