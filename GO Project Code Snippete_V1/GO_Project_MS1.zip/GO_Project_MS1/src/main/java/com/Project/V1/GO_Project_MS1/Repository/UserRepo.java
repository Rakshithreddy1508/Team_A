package com.Project.V1.GO_Project_MS1.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.Project.V1.GO_Project_MS1.Entity.UserEntity;

public interface UserRepo extends JpaRepository<UserEntity , String> {
	
	Optional<UserEntity> findByEmailId(String emailId);
	
	@Query("SELECT CASE WHEN COUNT(u) > 0 THEN true ELSE false END FROM UserEntity u WHERE u.emailId = :emailId")
    boolean existsByUserEmailId(@Param("emailId") String emailId);

}
