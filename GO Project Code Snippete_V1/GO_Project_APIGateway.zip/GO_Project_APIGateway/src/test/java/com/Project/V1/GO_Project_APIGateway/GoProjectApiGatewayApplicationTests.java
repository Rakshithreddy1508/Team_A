package com.Project.V1.GO_Project_APIGateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoProjectApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
