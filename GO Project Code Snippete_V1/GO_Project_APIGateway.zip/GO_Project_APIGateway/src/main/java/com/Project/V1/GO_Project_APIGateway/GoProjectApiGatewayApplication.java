
package com.Project.V1.GO_Project_APIGateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class GoProjectApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoProjectApiGatewayApplication.class, args);
	}

}
