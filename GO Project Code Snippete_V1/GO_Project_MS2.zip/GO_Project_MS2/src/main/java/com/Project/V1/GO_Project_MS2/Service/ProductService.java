package com.Project.V1.GO_Project_MS2.Service;

import java.util.List;

import com.Project.V1.GO_Project_MS2.DTO.ProductRequest;
import com.Project.V1.GO_Project_MS2.DTO.ProductResponse;

public interface ProductService {

	ProductResponse createProduct(ProductRequest productRequest);
	ProductResponse updateProduct(String id, ProductRequest productRequest);
	List<ProductResponse> getAllProducts();
	ProductResponse getProductById(String id);
    void deleteProduct(String id);
}
