package com.Project.V1.GO_Project_MS2.Mapper;

import org.springframework.stereotype.Component;

import com.Project.V1.GO_Project_MS2.DTO.CategoryRequest;
import com.Project.V1.GO_Project_MS2.DTO.CategoryResponse;
import com.Project.V1.GO_Project_MS2.Entity.CategoryEntity;

@Component
public class CategoryMapper {
	
	public CategoryEntity toEntity(CategoryRequest categoryRequest) {
		CategoryEntity categoryEntity = new CategoryEntity();
		categoryEntity.setName(categoryRequest.getName());
		categoryEntity.setDescription(categoryRequest.getDescription());
		// Map other properties
		return categoryEntity;
	}

	public CategoryResponse toResponse(CategoryEntity categoryEntity) {
		CategoryResponse categoryResponse = new CategoryResponse();
		categoryResponse.setId(categoryEntity.getId());
		categoryResponse.setName(categoryEntity.getName());
		categoryResponse.setDescription(categoryEntity.getDescription());
		// Map other properties
		return categoryResponse;
	}
	
	
}
