package com.Project.V1.GO_Project_MS2.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Project.V1.GO_Project_MS2.DTO.CategoryRequest;
import com.Project.V1.GO_Project_MS2.DTO.CategoryResponse;
import com.Project.V1.GO_Project_MS2.Entity.CategoryEntity;
import com.Project.V1.GO_Project_MS2.Mapper.CategoryMapper;
import com.Project.V1.GO_Project_MS2.Repository.CategoryRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class CategoryServiceImplementation implements CategoryService {
	
		@Autowired
		private CategoryRepository categoryRepository; 

		@Autowired
		private CategoryMapper categoryMapper;

		@Override
		public CategoryResponse createCategory(CategoryRequest categoryRequest) {
			CategoryEntity categoryEntity = categoryMapper.toEntity(categoryRequest);
			categoryEntity = categoryRepository.save(categoryEntity);
			return categoryMapper.toResponse(categoryEntity);
		}
		
	   
		@Override
		public CategoryResponse updateCategory (String id, CategoryRequest categoryRequest) {
			CategoryEntity existingCategory = categoryRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("Category not found"));

			existingCategory.setName(categoryRequest.getName());
			existingCategory.setDescription(categoryRequest.getDescription());
			// Update other properties

			existingCategory = categoryRepository.save(existingCategory);
			return categoryMapper.toResponse(existingCategory);
		}

		@Override
		public CategoryResponse getCategoryById(String id) {
			CategoryEntity categoryEntity = categoryRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("Category not found"));
			return categoryMapper.toResponse(categoryEntity);
		}

		@Override
		public void deleteCategory(String id) {
			CategoryEntity category = categoryRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("Category not found"));
			categoryRepository.delete(category);
		}


		@Override
		public List<CategoryResponse> getAllCategory() {
			// TODO Auto-generated method stub
			return null;
		}
		
	}
