package com.Project.V1.GO_Project_MS2.DTO;

public class ProductResponse {
	private String id;
	private String name;
	private String description;
	private String image_url_1;
	private String image_url_2;
	private String category_id;
	private double price ;
	private int quantity ;
	private double rating ;
	private boolean is_delivary_available ;
	private String manufacture_info ;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImage_url_1() {
		return image_url_1;
	}
	public void setImage_url_1(String image_url_1) {
		this.image_url_1 = image_url_1;
	}
	public String getImage_url_2() {
		return image_url_2;
	}
	public void setImage_url_2(String image_url_2) {
		this.image_url_2 = image_url_2;
	}
	public String getCategory_id() {
		return category_id;
	}
	public void setCategory_id(String category_id) {
		this.category_id = category_id;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public boolean isIs_delivary_available() {
		return is_delivary_available;
	}
	public void setIs_delivary_available(boolean is_delivary_available) {
		this.is_delivary_available = is_delivary_available;
	}
	public String getManufacture_info() {
		return manufacture_info;
	}
	public void setManufacture_info(String manufacture_info) {
		this.manufacture_info = manufacture_info;
	}
}
