package com.Project.V1.GO_Project_MS2.Service;

import java.util.List;

import com.Project.V1.GO_Project_MS2.DTO.CategoryRequest;
import com.Project.V1.GO_Project_MS2.DTO.CategoryResponse;

public interface CategoryService  {

	CategoryResponse createCategory(CategoryRequest categoryRequest);
	CategoryResponse updateCategory(String id, CategoryRequest categoryRequest);
	CategoryResponse getCategoryById(String id);
    void deleteCategory(String id);
	List<CategoryResponse> getAllCategory();
}
