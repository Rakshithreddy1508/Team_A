package com.Project.V1.GO_Project_MS2.Service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Project.V1.GO_Project_MS2.DTO.ProductRequest;
import com.Project.V1.GO_Project_MS2.DTO.ProductResponse;
import com.Project.V1.GO_Project_MS2.Entity.ProductEntity;
import com.Project.V1.GO_Project_MS2.Mapper.ProductMapper;
import com.Project.V1.GO_Project_MS2.Repository.ProductRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class ProductServiceImplementation implements ProductService {

	@Autowired
	private ProductRepository productRepository; 

	@Autowired
	private ProductMapper productMapper;

	@Override
	public ProductResponse createProduct(ProductRequest productRequest) {
		ProductEntity productEntity = productMapper.toEntity(productRequest);
		productEntity = productRepository.save(productEntity);
		return productMapper.toResponse(productEntity);
	}

	@Override
	public ProductResponse updateProduct(String id, ProductRequest productRequest) {
		ProductEntity existingProduct = productRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("Product not found"));

		existingProduct.setName(productRequest.getName());
		existingProduct.setDescription(productRequest.getDescription());
		existingProduct.setImage_url_1(productRequest.getImage_url_1());
		existingProduct.setImage_url_2(productRequest.getImage_url_2());
		existingProduct.setCategory_id(productRequest.getCategory_id());
		existingProduct.setPrice(productRequest.getPrice());
		existingProduct.setQuantity(productRequest.getQuantity());
		existingProduct.setRating(productRequest.getRating());
		existingProduct.setIs_delivary_available(productRequest.isIs_delivary_available());
		existingProduct.setManufacture_info(productRequest.getManufacture_info());
		existingProduct = productRepository.save(existingProduct);
		return productMapper.toResponse(existingProduct);
	}
	
	@Override
    public List<ProductResponse> getAllProducts() {
            List<ProductEntity> productEntities = productRepository.findAll();
            return productEntities.stream()
                .map(productMapper::toResponse)
                .collect(Collectors.toList());
    }

	@Override
	public ProductResponse getProductById(String id) {
		ProductEntity productEntity = productRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("Product not found"));
		return productMapper.toResponse(productEntity);
	}

	@Override
	public void deleteProduct(String id) {
		ProductEntity product = productRepository.findById(id)
				.orElseThrow(() -> new EntityNotFoundException("product not found"));
		productRepository.delete(product);
	}

	
}
