package com.Project.V1.GO_Project_MS2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoProjectMs2Application {

	public static void main(String[] args) {
		SpringApplication.run(GoProjectMs2Application.class, args);
	}

}
