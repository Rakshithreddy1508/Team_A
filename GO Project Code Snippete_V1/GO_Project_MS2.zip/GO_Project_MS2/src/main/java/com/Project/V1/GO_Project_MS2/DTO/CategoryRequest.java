package com.Project.V1.GO_Project_MS2.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class CategoryRequest {
	
	@NotBlank
//	@Size(min = 4, max = 10, message = "Name must be at least 8 characters long and less than 30 characters")
	private String name;
	
	@NotBlank
//	@Size(min = 8, max = 50, message = "Description must be at least 8 characters long and less than 50 characters")
	private String description;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

}
