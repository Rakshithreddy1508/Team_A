package com.Project.V1.GO_Project_MS2;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.Project.V1.GO_Project_MS2.DTO.CategoryRequest;
import com.Project.V1.GO_Project_MS2.DTO.CategoryResponse;
import com.Project.V1.GO_Project_MS2.Entity.CategoryEntity;
import com.Project.V1.GO_Project_MS2.Mapper.CategoryMapper;
import com.Project.V1.GO_Project_MS2.Repository.CategoryRepository;
import com.Project.V1.GO_Project_MS2.Service.CategoryServiceImplementation;

import jakarta.persistence.EntityNotFoundException;

@ExtendWith(MockitoExtension.class)
public class CategoryServiceImplementationTest {

    @InjectMocks
    private CategoryServiceImplementation categoryService;

    @Mock
    private CategoryRepository categoryRepository;

    @Mock
    private CategoryMapper categoryMapper;

    @BeforeEach
    void setUp() {
        // Set up common behavior or mocks here if needed before each test.
    }

    @Test
    public void testCreateCategory() throws Exception {
        CategoryRequest categoryRequest = new CategoryRequest();
        CategoryEntity categoryEntity = new CategoryEntity();
        CategoryResponse categoryResponse = new CategoryResponse();

        when(categoryMapper.toEntity(categoryRequest)).thenReturn(categoryEntity);
        when(categoryRepository.save(categoryEntity)).thenReturn(categoryEntity);
        when(categoryMapper.toResponse(categoryEntity)).thenReturn(categoryResponse);

        CategoryResponse result = categoryService.createCategory(categoryRequest);

        assertNotNull(result);
        assertEquals(categoryResponse, result);
    }

    @Test
    public void testUpdateCategory() throws Exception {
        String categoryId = "1";
        CategoryRequest categoryRequest = new CategoryRequest();
        CategoryEntity categoryEntity = new CategoryEntity();
        CategoryResponse categoryResponse = new CategoryResponse();

        when(categoryRepository.findById(categoryId)).thenReturn(java.util.Optional.of(categoryEntity));
        when(categoryRepository.save(categoryEntity)).thenReturn(categoryEntity);
        when(categoryMapper.toResponse(categoryEntity)).thenReturn(categoryResponse);

        CategoryResponse result = categoryService.updateCategory(categoryId, categoryRequest);

        assertNotNull(result);
        assertEquals(categoryResponse, result);
    }

    @Test
    public void testUpdateCategoryNotFound() {
        String categoryId = "1";
        CategoryRequest categoryRequest = new CategoryRequest();

        when(categoryRepository.findById(categoryId)).thenReturn(java.util.Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> {
            categoryService.updateCategory(categoryId, categoryRequest);
        });
    }

    @Test
    public void testGetCategoryById() throws Exception {
        String categoryId = "1";
        CategoryEntity categoryEntity = new CategoryEntity();
        CategoryResponse categoryResponse = new CategoryResponse();

        when(categoryRepository.findById(categoryId)).thenReturn(java.util.Optional.of(categoryEntity));
        when(categoryMapper.toResponse(categoryEntity)).thenReturn(categoryResponse);

        CategoryResponse result = categoryService.getCategoryById(categoryId);

        assertNotNull(result);
        assertEquals(categoryResponse, result);
    }

    @Test
    public void testGetCategoryByIdNotFound() {
        String categoryId = "1";

        when(categoryRepository.findById(categoryId)).thenReturn(java.util.Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> {
            categoryService.getCategoryById(categoryId);
        });
    }

    @Test
    public void testDeleteCategory() throws Exception {
        String categoryId = "1";
        CategoryEntity categoryEntity = new CategoryEntity();

        when(categoryRepository.findById(categoryId)).thenReturn(java.util.Optional.of(categoryEntity));

        categoryService.deleteCategory(categoryId);

        verify(categoryRepository, times(1)).delete(categoryEntity);
    }

    @Test
    public void testDeleteCategoryNotFound() {
        String categoryId = "1";

        when(categoryRepository.findById(categoryId)).thenReturn(java.util.Optional.empty());

        assertThrows(EntityNotFoundException.class, () -> {
            categoryService.deleteCategory(categoryId);
        });
    }
}
