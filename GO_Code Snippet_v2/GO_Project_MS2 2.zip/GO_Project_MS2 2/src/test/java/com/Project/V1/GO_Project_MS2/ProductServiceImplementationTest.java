package com.Project.V1.GO_Project_MS2;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.Project.V1.GO_Project_MS2.DTO.ProductRequest;
import com.Project.V1.GO_Project_MS2.DTO.ProductResponse;
import com.Project.V1.GO_Project_MS2.Entity.ProductEntity;
import com.Project.V1.GO_Project_MS2.Mapper.ProductMapper;
import com.Project.V1.GO_Project_MS2.Repository.ProductRepository;
import com.Project.V1.GO_Project_MS2.Service.ProductServiceImplementation;

@ExtendWith(MockitoExtension.class)
public class ProductServiceImplementationTest {
	@InjectMocks
	private ProductServiceImplementation productService;

	@Mock
	private ProductRepository productRepository;

	@Mock
	private ProductMapper productMapper;

	@BeforeEach
    public void setup() {
	
	}

	@Test
	public void testCreateProduct() {

		ProductRequest productRequest = new ProductRequest();
		ProductEntity productEntity = new ProductEntity();
		ProductResponse productResponse = new ProductResponse();

		when(productMapper.toEntity(productRequest)).thenReturn(productEntity);
		when(productRepository.save(productEntity)).thenReturn(productEntity);
		when(productMapper.toResponse(productEntity)).thenReturn(productResponse);

		ProductResponse result = productService.createProduct(productRequest);

		assertNotNull(result);

	}

	@Test
	public void testUpdateProduct() {

		String productId = "1";
		ProductRequest productRequest = new ProductRequest();
		ProductEntity existingProduct = new ProductEntity();
		existingProduct.setId(productId);
		ProductResponse productResponse = new ProductResponse();

		when(productRepository.findById(productId)).thenReturn(java.util.Optional.of(existingProduct));
		when(productRepository.save(existingProduct)).thenReturn(existingProduct);
		when(productMapper.toResponse(existingProduct)).thenReturn(productResponse);

		ProductResponse result = productService.updateProduct(productId, productRequest);

		assertNotNull(result);

	}

	@Test
	public void testGetProductById() {

		String productId = "1";
		ProductEntity productEntity = new ProductEntity();
		ProductResponse productResponse = new ProductResponse();

		when(productRepository.findById(productId)).thenReturn(java.util.Optional.of(productEntity));
		when(productMapper.toResponse(productEntity)).thenReturn(productResponse);

		ProductResponse result = productService.getProductById(productId);

		assertNotNull(result);

	}

	@Test
	public void testDeleteProduct() {

		String productId = "1";
		ProductEntity productEntity = new ProductEntity();

		when(productRepository.findById(productId)).thenReturn(java.util.Optional.of(productEntity));

		productService.deleteProduct(productId);

		verify(productRepository, times(1)).delete(productEntity);
	}

}