package com.Project.V1.GO_Project_MS2.DTO;

import java.util.List;

import com.Project.V1.GO_Project_MS2.Entity.ProductEntity;



public class CategoryResponse {
	
	private String id;
	private String name;
	private String description;
	
	private List<ProductEntity> productEntity;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<ProductEntity> getProductEntity() {
		return productEntity;
	}

	public void setProductEntity(List<ProductEntity> productEntity) {
		this.productEntity = productEntity;
	}
	
	
	
}
