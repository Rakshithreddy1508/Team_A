package com.Project.V1.GO_Project_MS2.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Project.V1.GO_Project_MS2.DTO.CategoryRequest;
import com.Project.V1.GO_Project_MS2.DTO.CategoryResponse;
import com.Project.V1.GO_Project_MS2.DTO.ProductRequest;
import com.Project.V1.GO_Project_MS2.DTO.ProductResponse;
import com.Project.V1.GO_Project_MS2.Service.CategoryService;

import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;

@RestController
@CrossOrigin
@RequestMapping("/mapi/category")

public class CategoryController {

	@Autowired
	private CategoryService categoryService;

	@PostMapping
	public ResponseEntity<?> createCategory(@Valid @RequestBody CategoryRequest categoryRequest) {
		try {
			CategoryResponse categoryResponse = categoryService.createCategory(categoryRequest);
			return ResponseEntity.status(HttpStatus.CREATED).body(categoryResponse);
		} catch (Exception e) {
			// Handle exceptions with a generic error message and a 500 Internal Server
			// Error response
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Failed to create the category: " + e.getMessage());
		}
	}

	@PutMapping("/{id}")
	public ResponseEntity<?> updateCategory(@PathVariable String id, @RequestBody CategoryRequest categoryRequest) {
		try {
			CategoryResponse categoryResponse = categoryService.updateCategory(id, categoryRequest);
			return ResponseEntity.ok(categoryResponse);
		} catch (EntityNotFoundException e) {
			// Handle the specific exception for "User not found" with a 404 Not Found
			// response and a message
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Category not found: " + e.getMessage());
		} catch (Exception e) {
			// Handle other exceptions with a generic error message and a 500 Internal
			// Server Error response
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Failed to update the Category: " + e.getMessage());
		}
	}

	@GetMapping
	public ResponseEntity<List<CategoryResponse>> getAllCategory() throws Exception {

		List<CategoryResponse> category = categoryService.getAllCategory();
		return new ResponseEntity<>(category, HttpStatus.OK);
	}

	@GetMapping("/{id}")
	public ResponseEntity<?> getCategoryById(@PathVariable String id) {
		try {
			CategoryResponse categoryResponse = categoryService.getCategoryById(id);
			return new ResponseEntity<>(categoryResponse, HttpStatus.OK);
		} catch (EntityNotFoundException e) {

			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Category not found: " + e.getMessage());
		} catch (Exception e) {

			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Failed to retrieve the category: " + e.getMessage());
		}
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteCategory(@PathVariable String id) {
		try {
			categoryService.deleteCategory(id);
			return ResponseEntity.ok("Deleted product successfully");
		} catch (EntityNotFoundException e) {
			// Handle the specific exception for "User not found" with a 404 Not Found
			// response and a message
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Category not found: " + e.getMessage());
		} catch (Exception e) {
			// Handle other exceptions with a generic error message and a 500 Internal
			// Server Error response
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Failed to delete the Category: " + e.getMessage());
		}
	}

	@PostMapping("/{categoryId}/fields")
	// @PreAuthorize("hasAuthority('User')" + "and authentication.principal.Id ==
	// #userId")
	public ResponseEntity<ProductResponse> addProduct(@PathVariable String categoryId,
			@RequestBody ProductRequest productRequest) {
		ProductResponse productResponse = categoryService.addProduct(categoryId, productRequest);
		return ResponseEntity.status(HttpStatus.CREATED).body(productResponse);
	}

	@GetMapping("/{categoryId}/fields")
	public List<ProductResponse> getAllfieldOfProduct(@PathVariable String categoryId) {
		return categoryService.getAllfieldOfProduct(categoryId);
	}

	@GetMapping("/{categoryId}/fields/{productId}")
	public ProductResponse getParticularfieldOfProduct(@PathVariable String categoryId,
			@PathVariable String productId) {
		return categoryService.getParticularfieldOfProduct(categoryId, productId);
	}

	@PutMapping("/{categoryId}/fields/{productId}")
	public ProductResponse updateParticularfieldOfProduct(@PathVariable String categoryId,
			@PathVariable String productId, @RequestBody ProductRequest productRequest) {
		return categoryService.updateParticularfieldOfProduct(categoryId, productId, productRequest);
	}

}
