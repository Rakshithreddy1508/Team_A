package com.Project.V1.GO_Project_MS2.Service;

import java.util.List;

import com.Project.V1.GO_Project_MS2.DTO.CategoryRequest;
import com.Project.V1.GO_Project_MS2.DTO.CategoryResponse;
import com.Project.V1.GO_Project_MS2.DTO.ProductRequest;
import com.Project.V1.GO_Project_MS2.DTO.ProductResponse;

import jakarta.validation.Valid;

public interface CategoryService  {

	CategoryResponse createCategory(CategoryRequest categoryRequest);
	CategoryResponse updateCategory(String id, CategoryRequest categoryRequest);
	CategoryResponse getCategoryById(String id);
    void deleteCategory(String id);
	List<CategoryResponse> getAllCategory();
	ProductResponse updateParticularfieldOfProduct(String category_Id, String product_Id,
			ProductRequest productRequest);
	ProductResponse addProduct(String category_Id, @Valid ProductRequest productRequest);
	ProductResponse getParticularfieldOfProduct(String category_Id, String product_Id);
	List<ProductResponse> getAllfieldOfProduct(String category_Id);
}
