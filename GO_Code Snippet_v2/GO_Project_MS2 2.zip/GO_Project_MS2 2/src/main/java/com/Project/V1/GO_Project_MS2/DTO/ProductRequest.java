package com.Project.V1.GO_Project_MS2.DTO;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class ProductRequest {
	@NotBlank
	@Size(min = 4, max = 10, message = "Name must be at least 8 characters long and less than 30 characters")
	private String name;
	
	@Size(min = 8, max = 50, message = "Product description must be at least 8 characters long and less than 50 characters")
	private String description;
	
	private String image_url_1;
	
	private String image_url_2;
	
	
	
	private double price ;
	
	private int quantity ;
	
	private double rating ;
	
	private boolean is_delivary_available ;
	
	@Size(min = 8, max = 50, message = "Manufacturer info must be at least 8 characters long and less than 50 characters")
	private String manufacture_info ;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImage_url_1() {
		return image_url_1;
	}
	public void setImage_url_1(String image_url_1) {
		this.image_url_1 = image_url_1;
	}
	public String getImage_url_2() {
		return image_url_2;
	}
	public void setImage_url_2(String image_url_2) {
		this.image_url_2 = image_url_2;
	}
	
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getRating() {
		return rating;
	}
	public void setRating(double rating) {
		this.rating = rating;
	}
	public boolean isIs_delivary_available() {
		return is_delivary_available;
	}
	public void setIs_delivary_available(boolean is_delivary_available) {
		this.is_delivary_available = is_delivary_available;
	}
	public String getManufacture_info() {
		return manufacture_info;
	}
	public void setManufacture_info(String manufacture_info) {
		this.manufacture_info = manufacture_info;
	}
	
}
