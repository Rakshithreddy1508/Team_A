package com.Project.V1.GO_Project_MS2.Mapper;

import org.springframework.stereotype.Component;

import com.Project.V1.GO_Project_MS2.DTO.ProductRequest;
import com.Project.V1.GO_Project_MS2.DTO.ProductResponse;
import com.Project.V1.GO_Project_MS2.Entity.ProductEntity;

@Component
public class ProductMapper {

	public ProductEntity toEntity(ProductRequest productRequest) {
		ProductEntity productEntity = new ProductEntity();
		productEntity.setName(productRequest.getName());
		productEntity.setDescription(productRequest.getDescription());
		productEntity.setImage_url_1(productRequest.getImage_url_1());
		productEntity.setImage_url_2(productRequest.getImage_url_2());

		productEntity.setPrice(productRequest.getPrice());
		productEntity.setQuantity(productRequest.getQuantity());
		productEntity.setRating(productRequest.getRating());
		productEntity.setIs_delivary_available(productRequest.isIs_delivary_available());
		productEntity.setManufacture_info(productRequest.getManufacture_info());
		
		
		
		// Map other properties
		return productEntity;
	}

	public ProductResponse toResponse(ProductEntity productEntity) {
		ProductResponse productResponse = new ProductResponse();
		productResponse.setId(productEntity.getId());
		productResponse.setName(productEntity.getName());
		productResponse.setDescription(productEntity.getDescription());
		productResponse.setImage_url_1(productEntity.getImage_url_1());
		productResponse.setImage_url_2(productEntity.getImage_url_2());
		productResponse.setPrice(productEntity.getPrice());
		productResponse.setQuantity(productEntity.getQuantity());
		productResponse.setRating(productEntity.getRating());
		productResponse.setIs_delivary_available(productEntity.isIs_delivary_available());
		productResponse.setManufacture_info(productEntity.getManufacture_info());
		
		// Map other properties
		return productResponse;
	}

}
