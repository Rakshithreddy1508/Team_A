package com.Project.V1.GO_Project_MS2.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.Project.V1.GO_Project_MS2.DTO.CategoryRequest;
import com.Project.V1.GO_Project_MS2.DTO.CategoryResponse;
import com.Project.V1.GO_Project_MS2.DTO.ProductRequest;
import com.Project.V1.GO_Project_MS2.DTO.ProductResponse;
import com.Project.V1.GO_Project_MS2.Entity.CategoryEntity;
import com.Project.V1.GO_Project_MS2.Entity.ProductEntity;
import com.Project.V1.GO_Project_MS2.Mapper.CategoryMapper;
import com.Project.V1.GO_Project_MS2.Mapper.ProductMapper;
import com.Project.V1.GO_Project_MS2.Repository.CategoryRepository;
import com.Project.V1.GO_Project_MS2.Repository.ProductRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class CategoryServiceImplementation implements CategoryService {
	
		@Autowired
		private CategoryRepository categoryRepository; 

		@Autowired
		private CategoryMapper categoryMapper;
		
		@Autowired
		private ProductMapper productMapper;
		
		@Autowired
		private ProductRepository productrepository;

		@Override
		public CategoryResponse createCategory(CategoryRequest categoryRequest) {
			CategoryEntity categoryEntity = categoryMapper.toEntity(categoryRequest);
			categoryEntity = categoryRepository.save(categoryEntity);
			return categoryMapper.toResponse(categoryEntity);
		}
		
	   
		@Override
		public CategoryResponse updateCategory (String id, CategoryRequest categoryRequest) {
			CategoryEntity existingCategory = categoryRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("Category not found"));

			existingCategory.setName(categoryRequest.getName());
			existingCategory.setDescription(categoryRequest.getDescription());
			// Update other properties

			existingCategory = categoryRepository.save(existingCategory);
			return categoryMapper.toResponse(existingCategory);
		}

		@Override
		public CategoryResponse getCategoryById(String id) {
			CategoryEntity categoryEntity = categoryRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("Category not found"));
			return categoryMapper.toResponse(categoryEntity);
		}

		@Override
		public void deleteCategory(String id) {
			CategoryEntity category = categoryRepository.findById(id)
					.orElseThrow(() -> new EntityNotFoundException("Category not found"));
			categoryRepository.delete(category);
		}


		@Override
		public List<CategoryResponse> getAllCategory() {
			List<CategoryEntity> categoryEntities = categoryRepository.findAll();
            return categoryEntities.stream()
                .map(categoryMapper::toResponse)
                .collect(Collectors.toList());
		}
		
		 @Override
		    public ProductResponse addProduct(String categoryId, ProductRequest productRequest){
		        Optional<CategoryEntity> category = categoryRepository.findById(categoryId);
		        if(category.isEmpty())
		        {
		            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
		        }
		        ProductEntity product = productMapper.toEntity(productRequest);
		        product.setCategoryEntity(category.get());
		        productrepository.save(product);
		        return  productMapper.toResponse(product);
		    }
		    
		    @Override
		    public List<ProductResponse> getAllfieldOfProduct(String categoryId) {
		        Optional<CategoryEntity> categoryOptional = categoryRepository.findById(categoryId);
		        
		        if (categoryOptional.isEmpty()) {
		            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "product not found with ID: " + categoryId);
		        }

		        CategoryEntity user = categoryOptional.get();
		        List<ProductEntity> id = user.getProductEntities();

		        // Map the list of addresses to a list of response objects
		        List<ProductResponse> productResponses = id.stream()
		                .map(productMapper::toResponse)
		                .collect(Collectors.toList());

		        return productResponses;
		    }

		    @Override
		    public ProductResponse getParticularfieldOfProduct(String categoryId, String productId) {
		        Optional<CategoryEntity> categoryOptional = categoryRepository.findById(categoryId);

		        if (categoryOptional.isEmpty()) {
		            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found with ID: " + categoryId);
		        }

		        CategoryEntity category = categoryOptional.get();

		        // Find the user address by ID
		        Optional<ProductEntity> productOptional = category.getProductEntities().stream()
		                .filter(address -> address.getId().equals(productId))
		                .findFirst();

		        if (productOptional.isEmpty()) {
		            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Category address not found with ID: " + productId);
		        }

		        // Map the user address to a response object
		        ProductEntity product = productOptional.get();
		        ProductResponse productResponse =productMapper.toResponse(product);

		        return productResponse;
		    }

		    
		    @Override
		    public ProductResponse updateParticularfieldOfProduct(String categoryId, String productId, ProductRequest updatedproductRequest) {
		        Optional<CategoryEntity> categoryOptional = categoryRepository.findById(categoryId);

		        if (categoryOptional.isEmpty()) {
		            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found with ID: " + categoryId);
		        }

		        CategoryEntity category = categoryOptional.get();

		        // Find the user address by ID
		        Optional<ProductEntity> productOptional = category.getProductEntities().stream()
		                .filter(address -> address.getId().equals(productId))
		                .findFirst();

		        if (productOptional.isEmpty()) {
		            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Product address not found with ID: " + productId);
		        }

		        // Update the user address with the new data
		        ProductEntity product = productOptional.get();
		        updateProductFields(product, updatedproductRequest);

		        // Save the updated user address
		        productrepository.save(product);

		        // Map the updated user address to a response object
		        ProductResponse addressResponse = productMapper.toResponse(product);

		        return addressResponse;
		    }

		    private void updateProductFields(ProductEntity Product, ProductRequest productRequest) {
		        
		    	Product.setName(productRequest.getName());
		    	Product.setDescription(productRequest.getDescription());
		    	Product.setPrice(productRequest.getPrice());
		    }

		    
		    
		}



