package com.Project.V1.GO_Project_MS2.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Project.V1.GO_Project_MS2.Entity.ProductEntity;



public interface ProductRepository extends JpaRepository<ProductEntity , String> {

}
