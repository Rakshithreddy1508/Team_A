package com.Project.V1.GO_Project_MS2.Entity;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "product_Details")
public class ProductEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	private String id;
	private String name;
	private String description;
	private String image_url_1;
	private String image_url_2;
	private double price ;
	private int quantity ;
	private double rating ;
	private boolean is_delivary_available ;
	private String manufacture_info ;
	
	@JsonIgnore
    @ManyToOne
    @JoinColumn(name="category_id")
    private CategoryEntity categoryEntity;

	public ProductEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductEntity(String id, String name, String description, String image_url_1, String image_url_2,
			double price, int quantity, double rating, boolean is_delivary_available, String manufacture_info,
			CategoryEntity categoryEntity) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.image_url_1 = image_url_1;
		this.image_url_2 = image_url_2;
		this.price = price;
		this.quantity = quantity;
		this.rating = rating;
		this.is_delivary_available = is_delivary_available;
		this.manufacture_info = manufacture_info;
		this.categoryEntity = categoryEntity;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getImage_url_1() {
		return image_url_1;
	}

	public void setImage_url_1(String image_url_1) {
		this.image_url_1 = image_url_1;
	}

	public String getImage_url_2() {
		return image_url_2;
	}

	public void setImage_url_2(String image_url_2) {
		this.image_url_2 = image_url_2;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public boolean isIs_delivary_available() {
		return is_delivary_available;
	}

	public void setIs_delivary_available(boolean is_delivary_available) {
		this.is_delivary_available = is_delivary_available;
	}

	public String getManufacture_info() {
		return manufacture_info;
	}

	public void setManufacture_info(String manufacture_info) {
		this.manufacture_info = manufacture_info;
	}

	public CategoryEntity getCategoryEntity() {
		return categoryEntity;
	}

	public void setCategoryEntity(CategoryEntity categoryEntity) {
		this.categoryEntity = categoryEntity;
	}

	@Override
	public String toString() {
		return "ProductEntity [id=" + id + ", name=" + name + ", description=" + description + ", image_url_1="
				+ image_url_1 + ", image_url_2=" + image_url_2 + ", price=" + price + ", quantity=" + quantity
				+ ", rating=" + rating + ", is_delivary_available=" + is_delivary_available + ", manufacture_info="
				+ manufacture_info + ", categoryEntity=" + categoryEntity + "]";
	}

	

}
