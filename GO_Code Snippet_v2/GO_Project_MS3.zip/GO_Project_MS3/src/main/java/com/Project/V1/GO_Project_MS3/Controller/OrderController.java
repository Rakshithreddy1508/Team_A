package com.Project.V1.GO_Project_MS3.Controller;




import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Project.V1.GO_Project_MS3.DTO.OrderRequest;
import com.Project.V1.GO_Project_MS3.DTO.OrderResponse;
import com.Project.V1.GO_Project_MS3.service.OrderService;

import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;


@RestController
@CrossOrigin
@RequestMapping("/napi/order")
public class OrderController {

	@Autowired
    private OrderService orderService;


    @PostMapping
    public ResponseEntity<?> createUser(@Valid @RequestBody OrderRequest orderRequest) {
        try {
            OrderResponse orderResponse = orderService.createOrder(orderRequest);
            return ResponseEntity.status(HttpStatus.CREATED).body(orderResponse);
        } catch (Exception e) {
            // Handle exceptions with a generic error message and a 500 Internal Server Error response
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create the order: " + e.getMessage());
        }
    }


    @GetMapping
    public ResponseEntity<List<OrderResponse>> getAllOrder() throws Exception{

            List<OrderResponse> order = orderService.getAllOrder();
            return new ResponseEntity<>(order, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getOrderById(@PathVariable String id) {
        try {
        	OrderResponse orderResponse = orderService.getOrderById(id);
            return new ResponseEntity<>(orderResponse, HttpStatus.OK);
        } catch (EntityNotFoundException e) {
            // Handle the specific exception for "User not found" with a 404 Not Found response and a message
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Order not found: " + e.getMessage());
        } catch (Exception e) {
            // Handle other exceptions with a generic error message and a 500 Internal Server Error response
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to retrieve the order: " + e.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateOrder(@PathVariable String id, @RequestBody OrderRequest orderRequest) {
        try {
        	OrderResponse orderResponse = orderService.updateOrder(id, orderRequest);
            return ResponseEntity.ok(orderResponse);
        } catch (EntityNotFoundException e) {
            // Handle the specific exception for "User not found" with a 404 Not Found response and a message
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Order not found: " + e.getMessage());
        } catch (Exception e) {
            // Handle other exceptions with a generic error message and a 500 Internal Server Error response
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to update the order: " + e.getMessage());
        }
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteOrder(@PathVariable String id) {
        try {
        	orderService.deleteOrder(id);
            return ResponseEntity.ok("Deleted order successfully");
        } catch (EntityNotFoundException e) {
            // Handle the specific exception for "User not found" with a 404 Not Found response and a message
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Order not found: " + e.getMessage());
        } catch (Exception e) {
            // Handle other exceptions with a generic error message and a 500 Internal Server Error response
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to delete the order: " + e.getMessage());
        }
    }

}