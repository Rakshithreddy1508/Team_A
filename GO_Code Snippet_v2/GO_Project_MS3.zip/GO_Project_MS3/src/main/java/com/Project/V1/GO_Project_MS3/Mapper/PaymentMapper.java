package com.Project.V1.GO_Project_MS3.Mapper;

import org.springframework.stereotype.Component;

import com.Project.V1.GO_Project_MS3.DTO.PaymentRequest;
import com.Project.V1.GO_Project_MS3.DTO.PaymentResponse;
import com.Project.V1.GO_Project_MS3.Entity.PaymentEntity;
@Component
public class PaymentMapper {


		public PaymentEntity toEntity(PaymentRequest paymentRequest) {
	        PaymentEntity paymentEntity = new PaymentEntity();

	        paymentEntity.setAmount (paymentRequest.getAmount ());
	        paymentEntity.setGst (paymentRequest.getGst ());
	        paymentEntity.setPg_charge (paymentRequest.getPg_charge ());

	        paymentEntity.setGst(paymentRequest.getGst());

	        return paymentEntity;

}


public PaymentResponse toResponse(PaymentEntity paymentEntity) {
       PaymentResponse paymentResponse = new PaymentResponse();

       paymentResponse.setId(paymentEntity.getId());
       paymentResponse.setAmount(paymentEntity.getAmount());
       paymentResponse.setGst(paymentEntity.getGst());
       paymentResponse.setPg_charge(paymentEntity.getPg_charge());

       paymentResponse.setGst(paymentEntity.getGst());


    return paymentResponse;
}
}