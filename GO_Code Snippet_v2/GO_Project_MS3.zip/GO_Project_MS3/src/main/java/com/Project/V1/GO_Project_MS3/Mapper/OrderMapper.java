package com.Project.V1.GO_Project_MS3.Mapper;

import org.springframework.stereotype.Component;

import com.Project.V1.GO_Project_MS3.DTO.OrderRequest;
import com.Project.V1.GO_Project_MS3.DTO.OrderResponse;
import com.Project.V1.GO_Project_MS3.Entity.OrderEntity;
@Component
public class OrderMapper {

	public OrderEntity toEntity(OrderRequest orderRequest) {
		   OrderEntity orderEntity = new OrderEntity();

		orderEntity.setOrder_ref_no(orderRequest.getOrder_ref_no());
		orderEntity.setProduct_id(orderRequest.getProduct_id());
		orderEntity.setUser_id(orderRequest.getUser_id());
        orderEntity.setUser_address_id(orderRequest.getUser_address_id());
        orderEntity.setPayment_id(orderRequest.getPayment_id());
        orderEntity.setDelivary_status(orderRequest.getDelivary_status());

       orderEntity.setProduct_id(orderRequest.getProduct_id());



        // Map other properties
        return orderEntity;

	}


public OrderResponse toResponse(OrderEntity orderEntity) {
       OrderResponse orderResponse = new OrderResponse();
       orderResponse.setId(orderEntity.getId());
       orderResponse.setOrder_ref_no(orderEntity.getOrder_ref_no());
       orderResponse.setProduct_id(orderEntity.getProduct_id());
       orderResponse.setUser_id(orderEntity.getUser_id());
       orderResponse.setUser_address_id(orderEntity.getUser_address_id());
       orderResponse.setPayment_id(orderEntity.getPayment_id());
       orderResponse.setDelivary_status(orderEntity.getDelivary_status());

       orderResponse.setProduct_id(orderEntity.getProduct_id());

       return orderResponse;
}

}