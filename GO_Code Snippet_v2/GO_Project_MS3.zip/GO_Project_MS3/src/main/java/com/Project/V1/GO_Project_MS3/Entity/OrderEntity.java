package com.Project.V1.GO_Project_MS3.Entity;

import java.util.Set;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="order_details")
public class OrderEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	private String id;
	private String order_ref_no;
	private String product_id;
	private String user_id;
	private String user_address_id;
	private String payment_id;
	private String delivary_status;

	@ManyToMany
	@JoinTable(
	  name = "order",
	  joinColumns = @JoinColumn(name = "order_id"),
	  inverseJoinColumns = @JoinColumn(name = "payment_id"))
	Set<PaymentEntity> paymentdetails;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOrder_ref_no() {
		return order_ref_no;
	}

	public void setOrder_ref_no(String order_ref_no) {
		this.order_ref_no = order_ref_no;
	}

	public String getProduct_id() {
		return product_id;
	}

	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getUser_address_id() {
		return user_address_id;
	}

	public void setUser_address_id(String user_address_id) {
		this.user_address_id = user_address_id;
	}

	public String getPayment_id() {
		return payment_id;
	}

	public void setPayment_id(String payment_id) {
		this.payment_id = payment_id;
	}

	public String getDelivary_status() {
		return delivary_status;
	}

	public void setDelivary_status(String delivary_status) {
		this.delivary_status = delivary_status;
	}

	public Set<PaymentEntity> getPayment() {
		return paymentdetails;
	}

	public void setPayment(Set<PaymentEntity> payment) {
		this.paymentdetails = payment;
	}

	public OrderEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderEntity(String id, String order_ref_no, String product_id, String user_id, String user_address_id,
			String payment_id, String delivary_status, Set<PaymentEntity> payment) {
		super();
		this.id = id;
		this.order_ref_no = order_ref_no;
		this.product_id = product_id;
		this.user_id = user_id;
		this.user_address_id = user_address_id;
		this.payment_id = payment_id;
		this.delivary_status = delivary_status;
		this.paymentdetails = payment;
	}

	@Override
	public String toString() {
		return "OrderEntity [id=" + id + ", order_ref_no=" + order_ref_no + ", product_id=" + product_id + ", user_id="
				+ user_id + ", user_address_id=" + user_address_id + ", payment_id=" + payment_id + ", delivary_status="
				+ delivary_status + ", payment=" + paymentdetails + "]";
	}


}
