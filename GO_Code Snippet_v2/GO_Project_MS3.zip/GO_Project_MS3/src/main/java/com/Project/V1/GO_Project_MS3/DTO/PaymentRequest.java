package com.Project.V1.GO_Project_MS3.DTO;

import java.util.Set;

import com.Project.V1.GO_Project_MS3.Entity.OrderEntity;

public class PaymentRequest {



	 private double amount ;
	 private double gst;
	 private double pg_charge ;

	 Set<OrderEntity> order;

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public double getGst() {
		return gst;
	}

	public void setGst(double gst) {
		this.gst = gst;
	}

	public double getPg_charge() {
		return pg_charge;
	}

	public void setPg_charge(double pg_charge) {
		this.pg_charge = pg_charge;
	}

	public Set<OrderEntity> getOrder() {
		return order;
	}

	public void setOrder(Set<OrderEntity> order) {
		this.order = order;
	}



}
