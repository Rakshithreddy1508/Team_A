package com.Project.V1.GO_Project_MS3.DTO;

import java.util.Set;

import com.Project.V1.GO_Project_MS3.Entity.PaymentEntity;

public class OrderResponse {
	private String id;
	private String order_ref_no;
	private String product_id;
	private String user_id;
	private String user_address_id;
	private String payment_id;
    private String delivary_status;

    Set<PaymentEntity> payment;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOrder_ref_no() {
		return order_ref_no;
	}

	public void setOrder_ref_no(String order_ref_no) {
		this.order_ref_no = order_ref_no;
	}

	public String getProduct_id() {
		return product_id;
	}

	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}

	public String getUser_id() {
		return user_id;
	}

	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}

	public String getUser_address_id() {
		return user_address_id;
	}

	public void setUser_address_id(String user_address_id) {
		this.user_address_id = user_address_id;
	}

	public String getPayment_id() {
		return payment_id;
	}

	public void setPayment_id(String payment_id) {
		this.payment_id = payment_id;
	}

	public String getDelivary_status() {
		return delivary_status;
	}

	public void setDelivary_status(String delivary_status) {
		this.delivary_status = delivary_status;
	}

	public Set<PaymentEntity> getPayment() {
		return payment;
	}

	public void setPayment(Set<PaymentEntity> payment) {
		this.payment = payment;
	}
}