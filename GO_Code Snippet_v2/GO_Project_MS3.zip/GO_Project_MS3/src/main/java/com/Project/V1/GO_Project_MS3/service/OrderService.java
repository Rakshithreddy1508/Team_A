package com.Project.V1.GO_Project_MS3.service;


import java.util.List;

import com.Project.V1.GO_Project_MS3.DTO.OrderRequest;
import com.Project.V1.GO_Project_MS3.DTO.OrderResponse;

public interface OrderService {

	OrderResponse createOrder(OrderRequest orderRequest);

	
    OrderResponse updateOrder(String id, OrderRequest orderRequest);
    OrderResponse getOrderById(String id);
  
    void deleteOrder(String id);


	List<OrderResponse> getAllOrder();
}
