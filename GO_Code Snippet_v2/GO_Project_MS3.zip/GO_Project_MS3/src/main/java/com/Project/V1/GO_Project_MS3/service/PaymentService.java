package com.Project.V1.GO_Project_MS3.service;



import java.util.List;

import com.Project.V1.GO_Project_MS3.DTO.PaymentRequest;
import com.Project.V1.GO_Project_MS3.DTO.PaymentResponse;

public interface PaymentService {

	PaymentResponse getPaymentById(String id);
	PaymentResponse createPayment(PaymentRequest paymentRequest);
	PaymentResponse updatePayment(String id, PaymentRequest paymentRequest);
	   void deletePayment(String id);
	List<PaymentResponse> getAllPayment();
}
