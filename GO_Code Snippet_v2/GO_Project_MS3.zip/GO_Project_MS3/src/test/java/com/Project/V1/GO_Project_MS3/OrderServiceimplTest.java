package com.Project.V1.GO_Project_MS3;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.Project.V1.GO_Project_MS3.DTO.OrderRequest;
import com.Project.V1.GO_Project_MS3.DTO.OrderResponse;
import com.Project.V1.GO_Project_MS3.Entity.OrderEntity;
import com.Project.V1.GO_Project_MS3.Mapper.OrderMapper;
import com.Project.V1.GO_Project_MS3.Repository.OrderRepository;
import com.Project.V1.GO_Project_MS3.service.OrderServiceimpl;

@ExtendWith(MockitoExtension.class)
public class OrderServiceimplTest {
 
    @InjectMocks
    private OrderServiceimpl orderService;
 
    @Mock
    private OrderRepository orderRepository;
 
    @Mock
    private OrderMapper orderMapper;
 
    @BeforeEach
    public void setup() {
        
    }
 
    @Test
    public void testCreateOrder() {
       
        OrderRequest orderRequest = new OrderRequest();
        OrderEntity orderEntity = new OrderEntity();
        OrderResponse orderResponse = new OrderResponse();
 
        when(orderMapper.toEntity(orderRequest)).thenReturn(orderEntity);
        when(orderRepository.save(orderEntity)).thenReturn(orderEntity);
        when(orderMapper.toResponse(orderEntity)).thenReturn(orderResponse);
 
       
        OrderResponse result = orderService.createOrder(orderRequest);
 
       
        assertNotNull(result);
        
    }
 
    @Test
    public void testUpdateOrder() {
      
        String orderId = "1";
        OrderRequest orderRequest = new OrderRequest();
        OrderEntity existingOrder = new OrderEntity();
        existingOrder.setId(orderId);
        OrderResponse orderResponse = new OrderResponse();
 
        when(orderRepository.findById(orderId)).thenReturn(java.util.Optional.of(existingOrder));
        when(orderRepository.save(existingOrder)).thenReturn(existingOrder);
        when(orderMapper.toResponse(existingOrder)).thenReturn(orderResponse);
 
        
        OrderResponse result = orderService.updateOrder(orderId, orderRequest);
 
      
        assertNotNull(result);
        
    }
 
    @Test
    public void testGetOrderById() {
        
        String orderId = "1";
        OrderEntity orderEntity = new OrderEntity();
        OrderResponse orderResponse = new OrderResponse();
 
        when(orderRepository.findById(orderId)).thenReturn(java.util.Optional.of(orderEntity));
        when(orderMapper.toResponse(orderEntity)).thenReturn(orderResponse);
 
        
        OrderResponse result = orderService.getOrderById(orderId);
 
 
        assertNotNull(result);
        
    }
 
    @Test
    public void testDeleteOrder() {
        
        String orderId = "1";
        OrderEntity orderEntity = new OrderEntity();
 
        when(orderRepository.findById(orderId)).thenReturn(java.util.Optional.of(orderEntity));
 
       
        orderService.deleteOrder(orderId);
 
       
        verify(orderRepository, times(1)).delete(orderEntity);
    }
}
