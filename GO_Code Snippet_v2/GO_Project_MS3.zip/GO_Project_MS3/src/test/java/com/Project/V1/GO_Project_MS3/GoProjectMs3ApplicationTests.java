package com.Project.V1.GO_Project_MS3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoProjectMs3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
