package com.Project.V1.GO_Project_MS3;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.Project.V1.GO_Project_MS3.DTO.PaymentRequest;
import com.Project.V1.GO_Project_MS3.DTO.PaymentResponse;
import com.Project.V1.GO_Project_MS3.Entity.PaymentEntity;
import com.Project.V1.GO_Project_MS3.Mapper.PaymentMapper;
import com.Project.V1.GO_Project_MS3.Repository.PaymentRepository;
import com.Project.V1.GO_Project_MS3.service.PaymentServiceimpl;

@ExtendWith(MockitoExtension.class)
	public class PaymentServiceimplTest {
	 
	    @InjectMocks
	    private PaymentServiceimpl paymentService;
	 
	    @Mock
	    private PaymentRepository paymentRepository;
	 
	    @Mock
	    private PaymentMapper paymentMapper;
	 
	    @BeforeEach
	    public void setup() {
	      
	    }
	 
	    @Test
	    public void testCreatePayment() {
	 
	        PaymentRequest paymentRequest = new PaymentRequest();
	        PaymentEntity paymentEntity = new PaymentEntity();
	        PaymentResponse paymentResponse = new PaymentResponse();
	 
	        when(paymentMapper.toEntity(paymentRequest)).thenReturn(paymentEntity);
	        when(paymentRepository.save(paymentEntity)).thenReturn(paymentEntity);
	        when(paymentMapper.toResponse(paymentEntity)).thenReturn(paymentResponse);
	 
	 
	        PaymentResponse result = paymentService.createPayment(paymentRequest);
	 
	      
	        assertNotNull(result);
	      
	    }
	 
	    @Test
	    public void testUpdatePayment() {
	     
	        String paymentId = "1";
	        PaymentRequest paymentRequest = new PaymentRequest();
	        PaymentEntity existingPayment = new PaymentEntity();
	        existingPayment.setId(paymentId);
	        PaymentResponse paymentResponse = new PaymentResponse();
	 
	        when(paymentRepository.findById(paymentId)).thenReturn(java.util.Optional.of(existingPayment));
	        when(paymentRepository.save(existingPayment)).thenReturn(existingPayment);
	        when(paymentMapper.toResponse(existingPayment)).thenReturn(paymentResponse);
	 
	      
	        PaymentResponse result = paymentService.updatePayment(paymentId, paymentRequest);
	 
	   
	        assertNotNull(result);
	      
	    }
	 
	    @Test
	    public void testGetPaymentById() {
	      
	        String paymentId = "1";
	        PaymentEntity paymentEntity = new PaymentEntity();
	        PaymentResponse paymentResponse = new PaymentResponse();
	 
	        when(paymentRepository.findById(paymentId)).thenReturn(java.util.Optional.of(paymentEntity));
	        when(paymentMapper.toResponse(paymentEntity)).thenReturn(paymentResponse);
	 
	      
	        PaymentResponse result = paymentService.getPaymentById(paymentId);
	 
	        
	        assertNotNull(result);
	        
	    }
	 
	    @Test
	    public void testDeletePayment() {
	    
	        String paymentId = "1";
	        PaymentEntity paymentEntity = new PaymentEntity();
	 
	        when(paymentRepository.findById(paymentId)).thenReturn(java.util.Optional.of(paymentEntity));
	 
	 
	        paymentService.deletePayment(paymentId);
	 
	        
	        verify(paymentRepository, times(1)).delete(paymentEntity);
	    }
}
