package com.Project.V1.GO_Project_Registry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoProjectRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
