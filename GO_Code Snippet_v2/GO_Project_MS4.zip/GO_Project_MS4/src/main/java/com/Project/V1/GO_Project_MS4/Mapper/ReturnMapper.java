package com.Project.V1.GO_Project_MS4.Mapper;

import org.springframework.stereotype.Component;

import com.Project.V1.GO_Project_MS4.DTO.ReturnRequest;
import com.Project.V1.GO_Project_MS4.DTO.ReturnResponse;
import com.Project.V1.GO_Project_MS4.entity.ReturnEntity;

@Component
public class ReturnMapper {

	public ReturnEntity toEntity(ReturnRequest ReturnRequest) {
       ReturnEntity ReturnEntity = new ReturnEntity();

       ReturnEntity.setUser_id(ReturnRequest.getUser_id());
       ReturnEntity.setProduct_id(ReturnRequest.getProduct_id());
       ReturnEntity.setIs_return_avilable(ReturnRequest.getIs_return_avilable());
       ReturnEntity.setImage_url_1(ReturnRequest.getImage_url_1());
       ReturnEntity.setImage_url_2(ReturnRequest.getImage_url_2());
       ReturnEntity.setImage_url_3(ReturnRequest.getImage_url_3());
        // Map other properties
        return ReturnEntity;
 }

	public ReturnResponse toResponse(ReturnEntity ReturnEntity) {
		ReturnResponse ReturnResponse = new ReturnResponse();
		ReturnResponse.setId(ReturnEntity.getId());
		ReturnResponse.setUser_id(ReturnEntity.getUser_id());
		ReturnResponse.setProduct_id(ReturnEntity.getProduct_id());
		ReturnResponse.setIs_return_avilable(ReturnEntity.getIs_return_avilable());
		ReturnResponse.setImage_url_1(ReturnEntity.getImage_url_1());
		ReturnResponse.setImage_url_2(ReturnEntity.getImage_url_2());
		ReturnResponse.setImage_url_3(ReturnEntity.getImage_url_3());
        // Map other properties
        return ReturnResponse;
    }
}
