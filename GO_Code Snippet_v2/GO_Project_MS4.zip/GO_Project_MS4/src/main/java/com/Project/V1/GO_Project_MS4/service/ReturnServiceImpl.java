package com.Project.V1.GO_Project_MS4.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Project.V1.GO_Project_MS4.DTO.ReturnRequest;
import com.Project.V1.GO_Project_MS4.DTO.ReturnResponse;
import com.Project.V1.GO_Project_MS4.Mapper.ReturnMapper;
import com.Project.V1.GO_Project_MS4.entity.ReturnEntity;
import com.Project.V1.GO_Project_MS4.repository.ReturnRepo;

import jakarta.persistence.EntityNotFoundException;

@Service
public class ReturnServiceImpl implements ReturnService{

	@Autowired
	private ReturnRepo rrepo;

	@Autowired
    private ReturnMapper rMapper;

	@Override
    public ReturnResponse createreturn(ReturnRequest returnRequest) {
        ReturnEntity returnentity = rMapper.toEntity(returnRequest);
        returnentity = rrepo.save(returnentity);
        return rMapper.toResponse(returnentity);
    }
	@Override
    public ReturnResponse updatereturn(String id, ReturnRequest returnRequest) {
        ReturnEntity existingreturn = rrepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("return not found"));

        existingreturn.setUser_id(returnRequest.getUser_id());
        existingreturn.setProduct_id(returnRequest.getProduct_id());
        existingreturn.setIs_return_avilable(returnRequest.getIs_return_avilable());
        existingreturn.setImage_url_1(returnRequest.getImage_url_1());
        existingreturn.setImage_url_2(returnRequest.getImage_url_2());
        existingreturn.setImage_url_3(returnRequest.getImage_url_3());
        // Update other properties

        existingreturn = rrepo.save(existingreturn);
        return rMapper.toResponse(existingreturn);
    }
	@Override
    public ReturnResponse getreturnById(String returnId) {
        ReturnEntity returnentity = rrepo.findById(returnId)
                .orElseThrow(() -> new EntityNotFoundException("return not found"));
        return rMapper.toResponse(returnentity);
    }

    @Override
    public void deletereturn(String id) {
        ReturnEntity user = rrepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("return not found"));
        rrepo.delete(user);
    }

    @Override
    public List<ReturnResponse> getAllreturn() {
        List<ReturnEntity> returnEntities = rrepo.findAll();
        return returnEntities.stream()
                .map(rMapper::toResponse)
                .collect(Collectors.toList());
    }
}
