package com.Project.V1.GO_Project_MS4.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Project.V1.GO_Project_MS4.entity.CommentEntity;

public interface CommentRepo extends JpaRepository<CommentEntity,String>{

}
