package com.Project.V1.GO_Project_MS4.DTO;

import jakarta.validation.constraints.Size;

public class CommentRequest {
	@Size(min = 8, max = 30, message = "Comments must be at least 8 characters long and less than 30 characters")
	private String comment;
	private String product_id;

	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getProduct_id() {
		return product_id;
	}
	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}
}
