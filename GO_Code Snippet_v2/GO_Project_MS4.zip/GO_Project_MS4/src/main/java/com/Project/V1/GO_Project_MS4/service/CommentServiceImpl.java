package com.Project.V1.GO_Project_MS4.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Project.V1.GO_Project_MS4.DTO.CommentRequest;
import com.Project.V1.GO_Project_MS4.DTO.CommentResponse;
import com.Project.V1.GO_Project_MS4.Mapper.CommentMapper;
import com.Project.V1.GO_Project_MS4.entity.CommentEntity;
import com.Project.V1.GO_Project_MS4.repository.CommentRepo;

import jakarta.persistence.EntityNotFoundException;

@Service
public  class CommentServiceImpl implements CommentService {

	@Autowired
	private CommentRepo crepo;

	@Autowired
    private CommentMapper commentMapper;

    @Override
    public CommentResponse createComment(CommentRequest commentRequest) {
        CommentEntity commententity = commentMapper.toEntity(commentRequest);
        commententity = crepo.save(commententity);
        return commentMapper.toResponse(commententity);
    }
    @Override
    public CommentResponse updateComment(String id, CommentRequest userRequest) {
        CommentEntity existingComment = crepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Comment not found"));

        existingComment.setComment(userRequest.getComment());
        existingComment.setProduct_id(userRequest.getProduct_id());
        // Update other properties

        existingComment = crepo.save(existingComment);
        return commentMapper.toResponse(existingComment);
    }
    @Override
    public CommentResponse getCommentById(String commentId) {
        CommentEntity commententity = crepo.findById(commentId)
                .orElseThrow(() -> new EntityNotFoundException("Comment not found"));
        return commentMapper.toResponse(commententity);
    }

    @Override
    public void deleteComment(String id) {
        CommentEntity user = crepo.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Comment not found"));
        crepo.delete(user);
    }

    @Override
    public List<CommentResponse> getAllComment() {
        List<CommentEntity> commentEntities = crepo.findAll();
        return commentEntities.stream()
                .map(commentMapper::toResponse)
                .collect(Collectors.toList());

    }
}
