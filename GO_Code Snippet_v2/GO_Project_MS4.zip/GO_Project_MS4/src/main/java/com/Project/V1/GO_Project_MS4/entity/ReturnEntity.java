package com.Project.V1.GO_Project_MS4.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="return_Details")
public class ReturnEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	private String id;
	private String product_id;
	private String user_id;
	private String is_return_avilable;
	private String image_url_1;
	private String image_url_2;
	private String image_url_3;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getProduct_id() {
		return product_id;
	}
	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getIs_return_avilable() {
		return is_return_avilable;
	}
	public void setIs_return_avilable(String is_return_avilable) {
		this.is_return_avilable = is_return_avilable;
	}
	public String getImage_url_1() {
		return image_url_1;
	}
	public void setImage_url_1(String image_url_1) {
		this.image_url_1 = image_url_1;
	}
	public String getImage_url_2() {
		return image_url_2;
	}
	public void setImage_url_2(String image_url_2) {
		this.image_url_2 = image_url_2;
	}
	public String getImage_url_3() {
		return image_url_3;
	}
	public void setImage_url_3(String image_url_3) {
		this.image_url_3 = image_url_3;
	}
	public ReturnEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ReturnEntity(String id, String product_id, String user_id, String is_return_avilable, String image_url_1,
			String image_url_2, String image_url_3) {
		super();
		this.id = id;
		this.product_id = product_id;
		this.user_id = user_id;
		this.is_return_avilable = is_return_avilable;
		this.image_url_1 = image_url_1;
		this.image_url_2 = image_url_2;
		this.image_url_3 = image_url_3;
	}
	@Override
	public String toString() {
		return "returnentity [id=" + id + ", product_id=" + product_id + ", user_id=" + user_id
				+ ", is_return_avilable=" + is_return_avilable + ", image_url_1=" + image_url_1 + ", image_url_2="
				+ image_url_2 + ", image_url_3=" + image_url_3 + "]";
	}

}
