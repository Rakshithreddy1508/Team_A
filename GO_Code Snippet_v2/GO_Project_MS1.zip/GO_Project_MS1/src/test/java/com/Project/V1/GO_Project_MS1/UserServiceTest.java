package com.Project.V1.GO_Project_MS1;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.Project.V1.GO_Project_MS1.DTO.UserRequest;
import com.Project.V1.GO_Project_MS1.DTO.UserResponse;
import com.Project.V1.GO_Project_MS1.Entity.UserEntity;
import com.Project.V1.GO_Project_MS1.Mapper.UserMapper;
import com.Project.V1.GO_Project_MS1.Repository.UserRepo;
import com.Project.V1.GO_Project_MS1.service.UserServiceImpl;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

    @InjectMocks
    
    private UserServiceImpl userService;

    @Mock
    private UserRepo userRepository;

    @Mock
    private UserMapper userMapper;
    
    @Mock
    private PasswordEncoder passwordEncoder;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    

    @Test
    public void testSignInUser() throws Exception {
        UserRequest userRequest = new UserRequest(); // Initialize with test data
        String hashedPassword = "hashedPassword"; // Replace with an actual hashed password
        UserEntity userEntity = new UserEntity(); // Initialize with test data
        userEntity.setPassword(hashedPassword); // Set the password in the userEntity

        when(userRepository.findByEmailId(userRequest.getEmailId())).thenReturn(Optional.of(userEntity));
        when(passwordEncoder.matches(userRequest.getPassword(), hashedPassword)).thenReturn(true);
        when(userMapper.toResponse(userEntity)).thenReturn(new UserResponse()); // Replace with actual response data

        UserResponse response = userService.signInUser(userRequest);

        assertNotNull(response);
        // Add assertions based on expected results.
    }


    
    
    @Test
    public void testSignInUserUserNotFound() {
        UserRequest userRequest = new UserRequest(); // Initialize with test data
        when(userRepository.findByEmailId(userRequest.getEmailId())).thenReturn(Optional.empty());

        assertThrows(Exception.class, () -> userService.signInUser(userRequest));
        // Verify that the user not found exception is thrown
    }

    @Test
    public void testSignUpUserUserAlreadyExists() {
        UserRequest userRequest = new UserRequest(); // Initialize with test data
        when(userRepository.existsByUserEmailId(userRequest.getEmailId())).thenReturn(true);

        assertThrows(Exception.class, () -> userService.signUpUser(userRequest));
        // Verify that the user already exists exception is thrown
    }
    
    @Test
    public void testSignInUserInvalidCredentials() {
        UserRequest userRequest = new UserRequest(); // Initialize with test data
        String hashedPassword = "hashedPassword"; // Replace with an actual hashed password
        UserEntity userEntity = new UserEntity(); // Initialize with test data
        when(userRepository.findByEmailId(userRequest.getEmailId())).thenReturn(Optional.of(userEntity));
        when(passwordEncoder.matches(userRequest.getPassword(), hashedPassword)).thenReturn(false);

        assertThrows(Exception.class, () -> userService.signInUser(userRequest));
        // Verify that the invalid credentials exception is thrown
    }


    @Test
    public void testCreateUser() {

        UserRequest userRequest = new UserRequest();
        UserEntity userEntity = new UserEntity();
        UserResponse userResponse = new UserResponse();
        when(userMapper.toEntity(userRequest)).thenReturn(userEntity);
        when(userRepository.save(userEntity)).thenReturn(userEntity);
        when(userMapper.toResponse(userEntity)).thenReturn(userResponse);
        UserResponse result = userService.createUser(userRequest);
        assertNotNull(result);
    }
 
    @Test
    public void testUpdateUser() {
        String userId = "1";
        UserRequest userRequest = new UserRequest();
        UserEntity existingUser = new UserEntity();
        existingUser.setId(userId);
        UserResponse userResponse = new UserResponse();
        when(userRepository.findById(userId)).thenReturn(java.util.Optional.of(existingUser));
        when(userRepository.save(existingUser)).thenReturn(existingUser);
        when(userMapper.toResponse(existingUser)).thenReturn(userResponse);
        UserResponse result = userService.updateUser(userId, userRequest);
        assertNotNull(result);
    }
 
    @Test
    public void testGetUserById() {
        String userId = "1";
        UserEntity userEntity = new UserEntity();
        UserResponse userResponse = new UserResponse();
        when(userRepository.findById(userId)).thenReturn(java.util.Optional.of(userEntity));
        when(userMapper.toResponse(userEntity)).thenReturn(userResponse);
        UserResponse result = userService.getUserById(userId);
        assertNotNull(result);
    }
 
    @Test
    public void testDeleteUser() {
        String userId = "1";
        UserEntity userEntity = new UserEntity();
        when(userRepository.findById(userId)).thenReturn(java.util.Optional.of(userEntity));
        userService.deleteUser(userId);
        verify(userRepository, times(1)).delete(userEntity);
    }

}

