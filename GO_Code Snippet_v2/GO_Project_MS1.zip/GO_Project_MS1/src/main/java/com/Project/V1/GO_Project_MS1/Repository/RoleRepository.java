package com.Project.V1.GO_Project_MS1.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Project.V1.GO_Project_MS1.Entity.RoleEntity;

public interface RoleRepository extends JpaRepository<RoleEntity, Integer> {
	 
}