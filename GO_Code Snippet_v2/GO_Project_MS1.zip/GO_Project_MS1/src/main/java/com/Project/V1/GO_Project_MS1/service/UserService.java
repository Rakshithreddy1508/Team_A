package com.Project.V1.GO_Project_MS1.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.Project.V1.GO_Project_MS1.DTO.UserAddressRequest;
import com.Project.V1.GO_Project_MS1.DTO.UserAddressResponse;
import com.Project.V1.GO_Project_MS1.DTO.UserRequest;
import com.Project.V1.GO_Project_MS1.DTO.UserResponse;
import com.Project.V1.GO_Project_MS1.Entity.UserEntity;

@Service
public interface UserService {
	
//	UserDetailsService userDetailsService();
    
	UserResponse createUser(UserRequest userRequest) throws Exception ;
	
	UserResponse updateUser(String id, UserRequest userRequest) throws Exception; 
	
	List<UserResponse> getAllUsers() throws Exception;
	
	UserResponse getUserById(String userId);
	
    void deleteUser(String id);
    
    UserResponse signUpUser(UserRequest userRequest) throws Exception;
    UserResponse signInUser(UserRequest userRequest) throws Exception;
    
    
    UserAddressResponse addAddress(String userId, UserAddressRequest addressRequest);
    
    List<UserAddressResponse> getAllAddressForUser(String userId);
    
    UserAddressResponse getParticularUserAddressOfUser(String userId, String userAddressId);
    
    UserAddressResponse updateParticularUserAddressOfUser(String userId, String userAddressId, UserAddressRequest updatedAddressRequest); 
    
    
    
    public void saveUser(UserEntity user);
    public UserEntity getUserByNameAndPassword(String name, String password) throws Exception;
    
    
    
}
