package com.Project.V1.GO_Project_MS1.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Project.V1.GO_Project_MS1.DTO.UserAddressRequest;
import com.Project.V1.GO_Project_MS1.DTO.UserAddressResponse;
import com.Project.V1.GO_Project_MS1.Entity.UserAddressEntity;
import com.Project.V1.GO_Project_MS1.Mapper.UserAddressMapper;
import com.Project.V1.GO_Project_MS1.Repository.UserAddressRepo;

import jakarta.persistence.EntityNotFoundException;

@Service
public class UserAddressServiceImpl implements UserAddressService{
	
	@Autowired
    private UserAddressRepo userAddressRepository; // You need to define a repository

    @Autowired
    private UserAddressMapper userAddressMap;
   

    @Override
    public UserAddressResponse addUserAddress(UserAddressRequest userAddressRequest){

            UserAddressEntity userAddressEntity = userAddressMap.toAddressEntity(userAddressRequest);
            userAddressEntity = userAddressRepository.save(userAddressEntity);
            return userAddressMap.toAddressResponse(userAddressEntity);
    }

    @Override
    public UserAddressResponse updateUserAddress(String id, UserAddressRequest userAddressRequest){

        	UserAddressEntity existingUserAddress = userAddressRepository.findById(id)
        
                .orElseThrow(() -> new EntityNotFoundException("User address not found"));
        
        existingUserAddress.setAddressLine1(userAddressRequest.getAddressLine1());
        existingUserAddress.setAddressLine2(userAddressRequest.getAddressLine2());
        existingUserAddress.setCity(userAddressRequest.getCity());
        existingUserAddress.setState(userAddressRequest.getState());
        existingUserAddress.setCountry(userAddressRequest.getCountry());
        
        existingUserAddress = userAddressRepository.save(existingUserAddress);
        return userAddressMap.toAddressResponse(existingUserAddress);
    }
    
    @Override
    public List<UserAddressResponse> getAllUserAddress() {
            List<UserAddressEntity> userAddressEntities = userAddressRepository.findAll();
            return userAddressEntities.stream()
                .map(userAddressMap::toAddressResponse)
                .collect(Collectors.toList());
    }

    @Override
    public UserAddressResponse getUserAddressById(String userAddressId){
        	UserAddressEntity userAddressEntity = userAddressRepository.findById(userAddressId)
                .orElseThrow(() -> new EntityNotFoundException("User Address not found"));
        return userAddressMap.toAddressResponse(userAddressEntity);
    }
    
    @Override
    public void deleteUserAddress(String id) {
        UserAddressEntity userAddress = userAddressRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("User Address not found"));
        userAddressRepository.delete(userAddress);
    }

}
