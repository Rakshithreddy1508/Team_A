package com.Project.V1.GO_Project_MS1.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Project.V1.GO_Project_MS1.DTO.UserAddressRequest;
import com.Project.V1.GO_Project_MS1.DTO.UserAddressResponse;
import com.Project.V1.GO_Project_MS1.service.UserAddressService;

import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;


@RestController
@CrossOrigin
@RequestMapping("/api/userAddress")
public class UserAddressController {
	
	@Autowired
    private UserAddressService userAddressService;
	

    @PostMapping
    public ResponseEntity<?> addUserAddress(@Valid @RequestBody UserAddressRequest userAddressRequest) {
        try {
            UserAddressResponse userAddressResponse = userAddressService.addUserAddress(userAddressRequest);
            return ResponseEntity.status(HttpStatus.CREATED).body(userAddressResponse);
        } catch (Exception e) {
            // Handle exceptions with a generic error message and a 500 Internal Server Error response
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create the user address: " + e.getMessage());
        }
    }

    
    @GetMapping
    public ResponseEntity<List<UserAddressResponse>> getAllUserAddress() throws Exception{

            List<UserAddressResponse> userAddress = userAddressService.getAllUserAddress();
            return new ResponseEntity<>(userAddress, HttpStatus.OK);
    }

    @GetMapping("/{userAddressId}")
    public ResponseEntity<?> getUserAddressById(@PathVariable String userAddressId) {
        try {
            UserAddressResponse userAddressResponse = userAddressService.getUserAddressById(userAddressId);
            return new ResponseEntity<>(userAddressResponse, HttpStatus.OK);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User Address not found: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to retrieve the user address: " + e.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateUserAddress(@PathVariable String id, @RequestBody UserAddressRequest userAddressRequest) {
        try {
            UserAddressResponse userAddressResponse = userAddressService.updateUserAddress(id, userAddressRequest);
            return ResponseEntity.ok(userAddressResponse);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User Address not found: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to update the user address: " + e.getMessage());
        }
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUserAddress(@PathVariable String id) {
        try {
            userAddressService.deleteUserAddress(id);
            return ResponseEntity.ok("Deleted user address successfully");
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User address not found: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to delete the user address: " + e.getMessage());
        }
    }

}
