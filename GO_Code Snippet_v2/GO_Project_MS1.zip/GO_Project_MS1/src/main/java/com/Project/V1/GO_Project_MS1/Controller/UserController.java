package com.Project.V1.GO_Project_MS1.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Project.V1.GO_Project_MS1.DTO.UserAddressRequest;
import com.Project.V1.GO_Project_MS1.DTO.UserAddressResponse;
import com.Project.V1.GO_Project_MS1.DTO.UserRequest;
import com.Project.V1.GO_Project_MS1.DTO.UserResponse;
import com.Project.V1.GO_Project_MS1.service.UserService;

import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Valid;


@RestController
@CrossOrigin
@RequestMapping("/api/user")
public class UserController {

	@Autowired
    private UserService userService;
	
	

	@PostMapping("/register")
    public ResponseEntity<String> signUpUser(@Valid @RequestBody UserRequest userRequest) {
        try {
            UserResponse userResponse = userService.signUpUser(userRequest);
            return ResponseEntity.ok("User registered successfully with ID: " + userResponse.getId());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("Username already in use");
        }
    }

    @PostMapping("/logIn")
    public ResponseEntity<String> signInUser(@RequestBody UserRequest userRequest) {
        try {
            UserResponse userResponse = userService.signInUser(userRequest);
            return ResponseEntity.ok("User registered successfully !! " + userResponse.getEmailId());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Username not found or password incorrect");
        }
    }
    
    @PostMapping
    public ResponseEntity<?> createUser(@Valid @RequestBody UserRequest userRequest) {
        try {
            UserResponse userResponse = userService.createUser(userRequest);
            return ResponseEntity.status(HttpStatus.CREATED).body(userResponse);
        } catch (Exception e) {
            // Handle exceptions with a generic error message and a 500 Internal Server Error response
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create the user: " + e.getMessage());
        }
    }

    
    @GetMapping
    public ResponseEntity<List<UserResponse>> getAllUsers() throws Exception{

            List<UserResponse> users = userService.getAllUsers();
            return new ResponseEntity<>(users, HttpStatus.OK);
    }

 //   @PreAuthorize("hasAuthority('ADMIN')")
    //@Secured("ROLE_ADMIN")
    
    
    
    @GetMapping("/{userId}")
    public ResponseEntity<?> getUserById(@PathVariable String userId) {
        try {
            UserResponse userResponse = userService.getUserById(userId);
            return new ResponseEntity<>(userResponse, HttpStatus.OK);
        } catch (EntityNotFoundException e) {
            // Handle the specific exception for "User not found" with a 404 Not Found response and a message
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found: " + e.getMessage());
        } catch (Exception e) {
            // Handle other exceptions with a generic error message and a 500 Internal Server Error response
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to retrieve the user: " + e.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateUser(@PathVariable String id, @RequestBody UserRequest userRequest) {
        try {
            UserResponse userResponse = userService.updateUser(id, userRequest);
            return ResponseEntity.ok(userResponse);
        } catch (EntityNotFoundException e) {
            // Handle the specific exception for "User not found" with a 404 Not Found response and a message
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found: " + e.getMessage());
        } catch (Exception e) {
            // Handle other exceptions with a generic error message and a 500 Internal Server Error response
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to update the user: " + e.getMessage());
        }
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable String id) {
        try {
            userService.deleteUser(id);
            return ResponseEntity.ok("Deleted user successfully");
        } catch (EntityNotFoundException e) {
            // Handle the specific exception for "User not found" with a 404 Not Found response and a message
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found: " + e.getMessage());
        } catch (Exception e) {
            // Handle other exceptions with a generic error message and a 500 Internal Server Error response
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to delete the user: " + e.getMessage());
        }
    }

    
    @PostMapping("/{userId}/addresses")
    //@PreAuthorize("hasAuthority('User')" + "and authentication.principal.Id == #userId")
    public ResponseEntity<UserAddressResponse> addAddress(@PathVariable String userId, @Valid @RequestBody UserAddressRequest addressRequest){
        UserAddressResponse addressResponse = userService.addAddress(userId,addressRequest);
        return  ResponseEntity.status(HttpStatus.CREATED).body(addressResponse);
    }
    
    
    @GetMapping("/{userId}/addresses")
    public List<UserAddressResponse> getAllAddressesForUser(@PathVariable String userId) {
        return userService.getAllAddressForUser(userId);
    }
    
    @GetMapping("/{userId}/addresses/{userAddressId}")
    public UserAddressResponse getParticularUserAddressOfUser(
            @PathVariable String userId,
            @PathVariable String userAddressId) {
        return userService.getParticularUserAddressOfUser(userId, userAddressId);
    }
    
    @PutMapping("/{userId}/addresses/{userAddressId}")
    public UserAddressResponse updateParticularUserAddressOfUser(
            @PathVariable String userId,
            @PathVariable String userAddressId,
            @RequestBody UserAddressRequest updatedAddressRequest) {
        return userService.updateParticularUserAddressOfUser(userId, userAddressId, updatedAddressRequest);
    }
    
    
}
