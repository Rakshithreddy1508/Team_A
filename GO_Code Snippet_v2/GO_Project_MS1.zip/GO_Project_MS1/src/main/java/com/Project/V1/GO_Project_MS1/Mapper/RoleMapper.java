package com.Project.V1.GO_Project_MS1.Mapper;

import org.springframework.stereotype.Component;

import com.Project.V1.GO_Project_MS1.DTO.RoleRequest;
import com.Project.V1.GO_Project_MS1.DTO.RoleResponse;
import com.Project.V1.GO_Project_MS1.Entity.RoleEntity;

@Component
public class RoleMapper {
	
    public RoleEntity create(RoleRequest roleRequest) {
    	RoleEntity roleEntity = new RoleEntity();
    		roleEntity.setId(roleRequest.getId());
    		roleEntity.setRoleType(roleRequest.getRoleType());
        return roleEntity;
    }

    public RoleResponse roleResponse(RoleEntity roleEntity) {
    	RoleResponse roleResponse = new RoleResponse();
    		roleResponse.setId(roleEntity.getId());
    		roleResponse.setRoleType(roleEntity.getRoleType());
        return roleResponse;
    }

}
