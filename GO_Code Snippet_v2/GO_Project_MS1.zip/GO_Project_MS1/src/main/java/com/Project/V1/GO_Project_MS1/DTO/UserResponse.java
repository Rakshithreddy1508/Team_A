package com.Project.V1.GO_Project_MS1.DTO;

import java.util.List;

import com.Project.V1.GO_Project_MS1.Entity.UserAddressEntity;

import jakarta.persistence.Column;
import jakarta.persistence.Id;

public class UserResponse {
	
	@Id
	private String id;
	
	@Column(name = "first_name")
	private String firstName;
	
	@Column(name = "last_name")
	private String lastName;
	
	@Column(name = "date_of_birth")
	private String dateOfBirth;
	
	@Column(name = "mobile_number")
	private String mobileNumber;
	
	@Column(name = "email_id")
	private String emailId;

	private List<UserAddressEntity> userAddressEntities;
	
	


	public List<UserAddressEntity> getUserAddressEntities() {
		return userAddressEntities;
	}

	public void setUserAddressEntities(List<UserAddressEntity> userAddressEntities) {
		this.userAddressEntities = userAddressEntities;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	
	
	
	
}