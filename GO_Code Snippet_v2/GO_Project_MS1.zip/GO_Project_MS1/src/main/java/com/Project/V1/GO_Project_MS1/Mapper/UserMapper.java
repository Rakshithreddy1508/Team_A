package com.Project.V1.GO_Project_MS1.Mapper;

import org.springframework.stereotype.Component;

import com.Project.V1.GO_Project_MS1.DTO.UserRequest;
import com.Project.V1.GO_Project_MS1.DTO.UserResponse;
import com.Project.V1.GO_Project_MS1.Entity.UserEntity;

@Component
public class UserMapper {
	
    public UserEntity toEntity(UserRequest userRequest) {
        UserEntity userEntity = new UserEntity();
        	userEntity.setFirstName(userRequest.getFirstName());
        	userEntity.setLastName(userRequest.getLastName());
        	userEntity.setDateOfBirth(userRequest.getDateOfBirth());
        	userEntity.setMobileNumber(userRequest.getMobileNumber());
        	userEntity.setEmailId(userRequest.getEmailId());
        	userEntity.setPassword(userRequest.getPassword());
        	userEntity.setLastLoggedIn(userRequest.getLastLoggedIn());
        return userEntity;
    }

    public UserResponse toResponse(UserEntity userEntity) {
        UserResponse userResponse = new UserResponse();
        	userResponse.setId(userEntity.getId());
        	userResponse.setFirstName(userEntity.getFirstName());
        	userResponse.setLastName(userEntity.getLastName());
        	userResponse.setDateOfBirth(userEntity.getDateOfBirth());
        	userResponse.setMobileNumber(userEntity.getMobileNumber());
        	userResponse.setEmailId(userEntity.getEmailId());
        	userResponse.setUserAddressEntities(userEntity.getUserAddressEntities());
        return userResponse;
    }

	
}