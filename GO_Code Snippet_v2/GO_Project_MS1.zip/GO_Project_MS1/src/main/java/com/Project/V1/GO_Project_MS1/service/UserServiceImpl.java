package com.Project.V1.GO_Project_MS1.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.Project.V1.GO_Project_MS1.DTO.UserAddressRequest;
import com.Project.V1.GO_Project_MS1.DTO.UserAddressResponse;
import com.Project.V1.GO_Project_MS1.DTO.UserRequest;
import com.Project.V1.GO_Project_MS1.DTO.UserResponse;
import com.Project.V1.GO_Project_MS1.Entity.UserAddressEntity;
import com.Project.V1.GO_Project_MS1.Entity.UserEntity;
import com.Project.V1.GO_Project_MS1.Mapper.UserAddressMapper;
import com.Project.V1.GO_Project_MS1.Mapper.UserMapper;
import com.Project.V1.GO_Project_MS1.Repository.UserAddressRepo;
import com.Project.V1.GO_Project_MS1.Repository.UserRepo;

import jakarta.persistence.EntityNotFoundException;

@Service
public class UserServiceImpl implements UserService{

	
	@Autowired
    private UserRepo userRepository;
	
	@Autowired
    private UserAddressRepo userAddressRepository;

    @Autowired
    private UserMapper userMapper;
    
    @Autowired
    private UserAddressMapper userAddressMapper;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void saveUser(UserEntity user) {
      userRepository.save(user);
    }
  

    @Override
    public UserResponse signUpUser(UserRequest userRequest) throws Exception {
        if (userRepository.existsByUserEmailId(userRequest.getEmailId())) {
            throw new Exception("Email is already in use");
        }

        UserEntity userEntity = userMapper.toEntity(userRequest);
        userEntity.setPassword(passwordEncoder.encode(userEntity.getPassword())); // Hash the password
        userEntity = userRepository.save(userEntity);

        return userMapper.toResponse(userEntity);
    }



    @Override
    public UserResponse signInUser(UserRequest userRequest) throws Exception {
        String emailId = userRequest.getEmailId();
        String password = userRequest.getPassword();
        
        UserEntity userEntity = userRepository.findByEmailId(emailId).orElseThrow(() -> new Exception("User with email not found: " + emailId));

        if (!passwordEncoder.matches(password, userEntity.getPassword())) {
            throw new Exception("Invalid credentials");
        }

        return userMapper.toResponse(userEntity);
    }

    
    
    @Override
    public UserResponse createUser(UserRequest userRequest){

            UserEntity userEntity = userMapper.toEntity(userRequest);
            userEntity = userRepository.save(userEntity);
            return userMapper.toResponse(userEntity);
    }
    
    

    @Override
    public UserResponse updateUser(String id, UserRequest userRequest){

        	UserEntity existingUser = userRepository.findById(id)
        
                .orElseThrow(() -> new EntityNotFoundException("User not found"));
        
        existingUser.setFirstName(userRequest.getFirstName());
        existingUser.setLastName(userRequest.getLastName());
        existingUser.setDateOfBirth(userRequest.getDateOfBirth());
        existingUser.setMobileNumber(userRequest.getMobileNumber());
        
        existingUser = userRepository.save(existingUser);
        return userMapper.toResponse(existingUser);
    }
    
    @Override
    public List<UserResponse> getAllUsers() {
            List<UserEntity> userEntities = userRepository.findAll();
            return userEntities.stream()
                .map(userMapper::toResponse)
                .collect(Collectors.toList());
    }

    @Override
    public UserResponse getUserById(String id) {
        UserEntity userEntity = userRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("User not found"));
        return userMapper.toResponse(userEntity);
    }
    
    @Override
    public void deleteUser(String id) {
        UserEntity user = userRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("User not found"));
        userRepository.delete(user);
    }
    
    
    
    //////////////////////
    
    @Override
    public UserAddressResponse addAddress(String userId, UserAddressRequest userAddressRequest){
        Optional<UserEntity> user = userRepository.findById(userId);
        if(user.isEmpty())
        {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        UserAddressEntity userAddress = userAddressMapper.toAddressEntity(userAddressRequest);
        userAddress.setUserEntity(user.get());
        userAddressRepository.save(userAddress);
        return  userAddressMapper.toAddressResponse(userAddress);
    }
    
    @Override
    public List<UserAddressResponse> getAllAddressForUser(String userId) {
        Optional<UserEntity> userOptional = userRepository.findById(userId);
        
        if (userOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found with ID: " + userId);
        }

        UserEntity user = userOptional.get();
        List<UserAddressEntity> addresses = user.getUserAddressEntities();

        // Map the list of addresses to a list of response objects
        List<UserAddressResponse> addressResponses = addresses.stream()
                .map(userAddressMapper::toAddressResponse)
                .collect(Collectors.toList());

        return addressResponses;
    }

    @Override
    public UserAddressResponse getParticularUserAddressOfUser(String userId, String userAddressId) {
        Optional<UserEntity> userOptional = userRepository.findById(userId);

        if (userOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found with ID: " + userId);
        }

        UserEntity user = userOptional.get();

        // Find the user address by ID
        Optional<UserAddressEntity> userAddressOptional = user.getUserAddressEntities().stream()
                .filter(address -> address.getId().equals(userAddressId))
                .findFirst();

        if (userAddressOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User address not found with ID: " + userAddressId);
        }

        // Map the user address to a response object
        UserAddressEntity userAddress = userAddressOptional.get();
        UserAddressResponse addressResponse = userAddressMapper.toAddressResponse(userAddress);

        return addressResponse;
    }

    
    @Override
    public UserAddressResponse updateParticularUserAddressOfUser(String userId, String userAddressId, UserAddressRequest updatedAddressRequest) {
        Optional<UserEntity> userOptional = userRepository.findById(userId);

        if (userOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found with ID: " + userId);
        }

        UserEntity user = userOptional.get();

        // Find the user address by ID
        Optional<UserAddressEntity> userAddressOptional = user.getUserAddressEntities().stream()
                .filter(address -> address.getId().equals(userAddressId))
                .findFirst();

        if (userAddressOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User address not found with ID: " + userAddressId);
        }

        // Update the user address with the new data
        UserAddressEntity userAddress = userAddressOptional.get();
        updateAddressFields(userAddress, updatedAddressRequest);

        // Save the updated user address
        userAddressRepository.save(userAddress);

        // Map the updated user address to a response object
        UserAddressResponse addressResponse = userAddressMapper.toAddressResponse(userAddress);

        return addressResponse;
    }

    private void updateAddressFields(UserAddressEntity userAddress, UserAddressRequest updatedAddressRequest) {
        // Update fields based on your requirements
        userAddress.setAddressLine1(updatedAddressRequest.getAddressLine1());
        userAddress.setAddressLine2(updatedAddressRequest.getAddressLine2());
        userAddress.setCity(updatedAddressRequest.getCity());
        userAddress.setState(updatedAddressRequest.getState());
        userAddress.setCountry(updatedAddressRequest.getCountry());

        // Add more fields to update as needed
    }


	@Override
	public UserEntity getUserByNameAndPassword(String name, String password) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

    
    
}


