//package com.Project.V1.GO_Project_MS1.Controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Bean;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.Project.V1.GO_Project_MS1.DTO.UserRequest;
//import com.Project.V1.GO_Project_MS1.DTO.UserResponse;
//import com.Project.V1.GO_Project_MS1.service.UserService;
//
//import jakarta.validation.Valid;
//
//@RestController
//@CrossOrigin
//@RequestMapping("/api/login")
//public class LoginController {
//	
//	@Autowired
//    private UserService userService;
//	
//	@PostMapping("/register")
//    public ResponseEntity<String> signUpUser(@Valid @RequestBody UserRequest userRequest) {
//        try {
//            UserResponse userResponse = userService.signUpUser(userRequest);
//            return ResponseEntity.ok("User registered successfully with ID: " + userResponse.getId());
//        } catch (Exception e) {
//            return ResponseEntity.status(HttpStatus.CONFLICT).body("Username already in use");
//        }
//    }
//
//    @PostMapping("/logIn")
//    public ResponseEntity<String> signInUser(@RequestBody UserRequest userRequest) {
//        try {
//            UserResponse userResponse = userService.signInUser(userRequest);
//            return ResponseEntity.ok("User registered successfully !! " + userResponse.getEmailId());
//        } catch (Exception e) {
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Username not found or password incorrect");
//        }
//    }
//
//}
