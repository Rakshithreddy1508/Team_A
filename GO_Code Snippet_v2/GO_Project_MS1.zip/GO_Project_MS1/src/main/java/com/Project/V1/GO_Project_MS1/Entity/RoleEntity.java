package com.Project.V1.GO_Project_MS1.Entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "role")
public class RoleEntity {

    @Id
    private String id;
    @Column(name = "created_by")
    private String createdBy ;
    @Column(name = "created_date")
    private Date createdDate ;
    @Column(name = "last_updated_by")
    private String  lastUpdatedBy;
    @Column(name = "last_updated_date")
    private Date lastUpdatedDate;
    @Column(name="role_type")
    private String roleType;

    @JsonIgnore
    @OneToMany(mappedBy = "roleEntity")
    private List<UserEntity> userEntity = new ArrayList<>() ;

    
    public RoleEntity() {
		super();
		// TODO Auto-generated constructor stub
	}


	public RoleEntity(String id, String createdBy, Date createdDate, String lastUpdatedBy, Date lastUpdatedDate,
			String roleType, List<UserEntity> userEntity) {
		super();
		this.id = id;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedDate = lastUpdatedDate;
		this.roleType = roleType;
		this.userEntity = userEntity;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public Date getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}


	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}


	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}


	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}


	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}


	public String getRoleType() {
		return roleType;
	}


	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}


	public List<UserEntity> getUserEntity() {
		return userEntity;
	}


	public void setUserEntity(List<UserEntity> userEntity) {
		this.userEntity = userEntity;
	}


	@Override
	public String toString() {
		return "RoleEntity [id=" + id + ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", lastUpdatedBy="
				+ lastUpdatedBy + ", lastUpdatedDate=" + lastUpdatedDate + ", roleType=" + roleType + ", userEntity="
				+ userEntity + "]";
	}
    
    

}