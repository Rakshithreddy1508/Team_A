package com.Project.V1.GO_Project_MS1.Mapper;

import org.springframework.stereotype.Component;

import com.Project.V1.GO_Project_MS1.DTO.UserAddressRequest;
import com.Project.V1.GO_Project_MS1.DTO.UserAddressResponse;
import com.Project.V1.GO_Project_MS1.Entity.UserAddressEntity;
import com.Project.V1.GO_Project_MS1.Entity.UserEntity;

@Component
public class UserAddressMapper {
	
	public UserAddressEntity toAddressEntity(UserAddressRequest userAddressRequest) {
        UserAddressEntity userAddressEntity = new UserAddressEntity();
        	userAddressEntity.setAddressLine1(userAddressRequest.getAddressLine1());
        	userAddressEntity.setAddressLine2(userAddressRequest.getAddressLine2());
        	userAddressEntity.setCity(userAddressRequest.getCity());
        	userAddressEntity.setState(userAddressRequest.getState());
        	userAddressEntity.setCountry(userAddressRequest.getCountry());
        return userAddressEntity;
    }
	
	public UserAddressResponse toAddressResponse(UserAddressEntity userAddressEntity) {
		UserAddressResponse userAddressResponse = new UserAddressResponse();
			userAddressResponse.setId(userAddressEntity.getId());
			userAddressResponse.setAddressLine1(userAddressEntity.getAddressLine1());
			userAddressResponse.setAddressLine2(userAddressEntity.getAddressLine2());
			userAddressResponse.setCity(userAddressEntity.getCity());
			userAddressResponse.setState(userAddressEntity.getState());
			userAddressResponse.setCountry(userAddressEntity.getCountry());
        return userAddressResponse;
    }

}


