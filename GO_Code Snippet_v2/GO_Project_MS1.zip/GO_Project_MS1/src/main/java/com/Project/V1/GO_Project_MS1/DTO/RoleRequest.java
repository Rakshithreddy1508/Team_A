package com.Project.V1.GO_Project_MS1.DTO;

public class RoleRequest {

    private String id;
    private  String roleType;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRoleType() {
		return roleType;
	}
	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}
    
    
}
