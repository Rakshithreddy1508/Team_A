package com.Project.V1.GO_Project_MS1.service;

import java.util.List;

import com.Project.V1.GO_Project_MS1.DTO.UserAddressRequest;
import com.Project.V1.GO_Project_MS1.DTO.UserAddressResponse;

public interface UserAddressService {
	
	UserAddressResponse addUserAddress(UserAddressRequest userAddressRequest);
	
	UserAddressResponse updateUserAddress(String id, UserAddressRequest userAddressRequest) throws Exception; 
	
	List<UserAddressResponse> getAllUserAddress() throws Exception;
	
	UserAddressResponse getUserAddressById(String userAddressId);
	
	void deleteUserAddress(String id);

}
